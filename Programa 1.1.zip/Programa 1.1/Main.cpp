#include "Main.h"
#include "3ds.h"

HDC			hDC=NULL;		// Dispositivo de contexto GDI
HGLRC		hRC=NULL;		// Contexto de renderizado
HWND		hWnd=NULL;		// Manejador de ventana
HINSTANCE	hInstance;		// Instancia de la aplicacion

bool	keys[256];			// Arreglo para el manejo de teclado
bool	active=TRUE;		// Bandera de ventana activa

int glWidth;
int glHeight;

//Variable para cambiar entre render s�lido y alambrado
int renderModo;

//variables para la c�mara
CVector PosCam;
CVector ObjCam;


//Apuntador para primitivas de cuadricas
GLUquadricObj	*e;

//Nombre y ubicaci�n de los modelos
#define FILE_NAME1  "Modelos/modelo1.3ds"
#define FILE_NAME2  "Modelos/modelo2.3ds"
#define FILE_NAME3  "Modelos/modelo3.3ds"

//Contenedores de texturas de cada modelo
CTga textureModel1[4];
CTga textureModel2[4];
CTga textureModel3[4];

//Contenedor de texturas para el escenario
CTga textureName[20];

//Objeto que da acceso a las funciones del cargador 3ds
CLoad3DS g_Load3ds;

//Instancias de la estructura que almacenaran los datos de cada modelo
t3DModel g_3DModel1;
t3DModel g_3DModel2;
t3DModel g_3DModel3;

//Objeto para acceder a las variables de control del personaje
paramObjCam player1;

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaracion de WndProc (Procedimiento de ventana)

GLvoid ReDimensionaEscenaGL(GLsizei width, GLsizei height)	// Redimensiona e inicializa la ventana
{
	if (height==0)							// Para que no se presente una division por cero
	{
		height=1;							// la altura se iguala a 1
	}

	glViewport(0,0,width,height);					// Resetea el puerto de vista

	glMatrixMode(GL_PROJECTION);					// Selecciona la Matriz de Proyeccion
	glLoadIdentity();								// Resetea la Matriz de Proyeccion

	// Calcula el radio de aspecto o proporcion de medidas de la ventana
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,2000.0f);
	
	glMatrixMode(GL_MODELVIEW);							// Selecciona la Matriz de Vista de Modelo
	glLoadIdentity();									// Resetea la Matriz de Vista de Modelo

	glWidth=width;
	glHeight=height;
}

int CargaModelos()
{
	if(!g_Load3ds.Load3DSFile(FILE_NAME1, &g_3DModel1, textureModel1))
		return 0;
	if(!g_Load3ds.Load3DSFile(FILE_NAME2, &g_3DModel2, textureModel2))
		return 0;
	if(!g_Load3ds.Load3DSFile(FILE_NAME3, &g_3DModel3, textureModel3))
		return 0;
	
	return TRUE;
}

void DescargaModelos()
{
	g_Load3ds.UnLoad3DSFile(&g_3DModel1, textureModel1);
	g_Load3ds.UnLoad3DSFile(&g_3DModel2, textureModel2);
	g_Load3ds.UnLoad3DSFile(&g_3DModel3, textureModel3);
}

void inicializaCamara()
{
	PosCam=CVector(0.0f, 50.0f, 140.0f);
	ObjCam=CVector(0.0f, 50.0f, 0.0f);
}


int IniGL(GLvoid)										// Aqui se configuran los parametros iniciales de OpenGL
{
	glShadeModel(GL_SMOOTH);							// Activa Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Fondo negro
	glClearDepth(1.0f);									// Valor para el Depth Buffer
	glEnable(GL_DEPTH_TEST);							// Activa Depth Testing
	glDepthFunc(GL_LEQUAL);								// Tipo de Depth Testing a usar
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Correccion de c�lculos de perspectiva

	glCullFace(GL_BACK);								// Configurado para eliminar caras traseras
	glEnable(GL_CULL_FACE);								// Activa eliminacion de caras ocultas

	e=gluNewQuadric();

	inicializaCamara(); //Se agrego

	return TRUE;										
}

void DibujaEjes()
{
	glBegin(GL_LINES);
		//Eje X
		glColor3f(1.0f,0.0f,0.0f);
		glVertex3f(-100.0f, 0.0f, 0.0f);
		glVertex3f( 100.0f, 0.0f, 0.0f);

		//Eje Y
		glColor3f(0.0f,1.0f,0.0f);
		glVertex3f(0.0f, -100.0f, 0.0f);
		glVertex3f(0.0f,  100.0f, 0.0f);

		//Eje Z
		glColor3f(0.0f,0.0f,1.0f);
		glVertex3f(0.0f, 0.0f, -100.0f);
		glVertex3f(0.0f, 0.0f,  100.0f);
	glEnd();

	glPointSize(10.0f);

	glBegin(GL_POINTS);
		//"Flecha" eje X
		glColor3f(1.0f,0.0f,0.0f);
		glVertex3f( 100.0f, 0.0f, 0.0f);

		//"Flecha" eje Y
		glColor3f(0.0f,1.0f,0.0f);
		glVertex3f(0.0f,  100.0f, 0.0f);

		//"Flecha" eje Z
		glColor3f(0.0f,0.0f,1.0f);
		glVertex3f(0.0f, 0.0f,  100.0f);
	glEnd();

	glPointSize(1.0f);

	glColor3f(1.0f,1.0f,1.0f);
}

void dibujaCaja()
{
	//Plano 1
	glBegin(GL_QUADS);
		glColor3f(0.003f, 0.38f, 0.27f);
		glVertex3f(-3.0f, 0.0f, 3.0f);
		glVertex3f( 3.0f, 0.0f, 3.0f);
		glVertex3f( 3.0f, 6.0f, 3.0f);
		glVertex3f(-3.0f, 6.0f, 3.0f);
	glEnd();

	//Plano 2
	glBegin(GL_QUADS);
		glColor3f(0.003f, 0.38f, 0.27f);
		glVertex3f(-3.0f, 6.0f,  3.0f);
		glVertex3f( 3.0f, 6.0f,  3.0f);
		glVertex3f( 3.0f, 6.0f, -3.0f);
		glVertex3f(-3.0f, 6.0f, -3.0f);
	glEnd();

	//Plano 3
	glBegin(GL_QUADS);
		glColor3f(0.003f, 0.25f, 0.18f);
		glVertex3f(3.0f, 0.0f,  3.0f);
		glVertex3f(3.0f, 0.0f, -3.0f);
		glVertex3f(3.0f, 6.0f, -3.0f);
		glVertex3f(3.0f, 6.0f,  3.0f);
	glEnd();

	//Plano 4
	glBegin(GL_QUADS);
		glColor3f(0.003f, 0.25f, 0.18f);
		glVertex3f(-3.0f, 0.0f, -3.0f);
		glVertex3f(-3.0f, 0.0f,  3.0f);
		glVertex3f(-3.0f, 6.0f,  3.0f);
		glVertex3f(-3.0f, 6.0f, -3.0f);
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);

}
void dibujaIMAGE(){

	//plano delantero
	glBegin(GL_QUADS);
		glColor3f(0.4f, 0.8f, 0.0f);
		glVertex3f( 2.0f, 2.0f, 2.0f);
		glVertex3f( 23.0f, 2.0f,2.0f);
		glVertex3f( 23.0f,8.0f,2.0f);
		glVertex3f(2.0f, 8.0f, 2.0f);
	glEnd();

	//plano inferior
	glBegin(GL_QUADS);
		glColor3f(0.47f, 0.94f, 0.0f);
		glVertex3f( 23.0f, 2.0f, 2.0f);
		glVertex3f( 2.0f, 2.0f,2.0f);
		glVertex3f( 0.0f,0.0f,0.0f);
		glVertex3f(25.0f, 0.0f, 0.0f);
	glEnd();

	//plano superior
	glBegin(GL_QUADS);
		glColor3f(0.47f, 0.94f, 0.0f);
		glVertex3f( 2.0f, 8.0f, 2.0f);
		glVertex3f( 23.0f, 8.0f,2.0f);
		glVertex3f( 25.0f,10.0f,0.0f);
		glVertex3f(0.0f,10.0f, 0.0f);
	glEnd();

	//plano izquierdo
	glBegin(GL_QUADS);
		glColor3f(0.28f, 0.56f, 0.0f);
		glVertex3f( 23.0f, 2.0f,2.0f);
		glVertex3f( 25.0f, 0.0f,0.0f);
		glVertex3f( 25.0f,10.0f,0.0f);
		glVertex3f( 23.0f, 8.0f,2.0f);
	glEnd();

	//plano derecho
	glBegin(GL_QUADS);
		glColor3f(0.28f, 0.56f, 0.0f);
		glVertex3f( 0.0f, 0.0f,0.0f);
		glVertex3f( 2.0f, 2.0f,2.0f);
		glVertex3f( 2.0f,8.0f,2.0f);
		glVertex3f( 0.0f,10.0f,0.0f);
	glEnd();


}
void dibujaCostal()
{
	//Dibujar aqu� los planos que forman el costal
	//PLANO ENFRENTE
		glBegin(GL_QUADS);
		glColor3f(0.85f, 0.45f, 0.909f);
		glVertex3f(-7.0f, 0.0f, 4.0f);
		glVertex3f( 7.0f, 0.0f, 4.0f);
		glVertex3f( 5.0f, 1.8f, 4.0f);
		glVertex3f(-5.0f, 1.8f, 4.0f);
	glEnd();

	//PLANO ENFRENTE ABAJO
		glBegin(GL_QUADS);
		glColor3f(0.474f, 0.086f, 0.529f);
		glVertex3f(-7.0f, 0.0f, 4.0f);
		glVertex3f(-5.0f, -1.8f, 4.0f);
		glVertex3f(5.0f, -1.8f, 4.0f);
		glVertex3f(7.0f, 0.0f, 4.0f);
	glEnd();

	//PLANO TAPA ARRIBA
		glBegin(GL_QUADS);
		glColor3f(0.737f, 0.137f, 0.819f);
		glVertex3f(5.0f, 1.8f, -4.0f);
		glVertex3f(-5.0f, 1.8f, -4.0f);
		glVertex3f(-5.0f, 1.8f, 4.0f);
		glVertex3f(5.0f, 1.8f, 4.0f);
	glEnd();

	//PLANO TAPA  ARRIBA LADO DERECHO
		glBegin(GL_QUADS);
		glColor3f(0.607f, 0.113f, 0.678f);
		glVertex3f(7.0f, 0.0f, 4.0f);
		glVertex3f(7.0f, 0.0f, -4.0f);
		glVertex3f(5.0f, 1.8f, -4.0f);
		glVertex3f(5.0f, 1.8f, 4.0f);
	glEnd();

	//PLANO TAPA  ABAJO LADO DERECHO
		glBegin(GL_QUADS);
		glColor3f(0.27f, 0.05f, 0.301f);
		glVertex3f(5.0f, -1.8f, 4.0f);
		glVertex3f(5.0f, -1.8f, -4.0f);
		glVertex3f(7.0f, 0.0f, -4.0f);
		glVertex3f(7.0f, 0.0f, 4.0f);
	glEnd();

	//PLANO TAPA  ARRIBA LADO IZQUIERDO
		glBegin(GL_QUADS);
		glColor3f(0.607f, 0.113f, 0.678f);
		glVertex3f(-5.0f, 1.8f, 4.0f);
		glVertex3f(-5.0f, 1.8f, -4.0f);
		glVertex3f(-7.0f, 0.0f, -4.0f);
		glVertex3f(-7.0f, 0.0f, 4.0f);
     glEnd();

	 //PLANO TAPA  ABAJO LADO IZQUIERDO
		glBegin(GL_QUADS);
		glColor3f(0.27f, 0.05f, 0.301f);
		glVertex3f(-5.0f, -1.8f, -4.0f);
		glVertex3f(-5.0f, -1.8f, 4.0f);
		glVertex3f(-7.0f, 0.0f, 4.0f);
		glVertex3f(-7.0f, 0.0f, -4.0f);
     glEnd();
}


void dibujaEscalera()
{
	//Plano 1  LADO DERECHO
	glBegin(GL_QUADS);
		glColor3f(0.968f, 0.905f, 0.146f);
		glVertex3f(-20.0f,  0.0f, 6.0f);
		glVertex3f(-14.0f,  0.0f, 6.0f);
		glVertex3f( 20.0f, 37.0f, 6.0f);
		glVertex3f( 14.0f, 37.0f, 6.0f);
	glEnd();

    //Plano 2   FRENTE
	glBegin(GL_QUADS);
		glColor3f(0.85f, 0.788f, 0.035f);
		glVertex3f(14.0f,  37.0f, 6.0f);
		glVertex3f(14.0f,  37.0f, -6.0f);
		glVertex3f( -20.0f, 0.0f, -6.0f);
		glVertex3f( -20.0f, 0.0f, 6.0f);
	glEnd();

	//Dibujar aqu� el resto de la escalera
}

void dibujaEscalon()
{
	    //PARTE IZQUIERDA ESCALON
	glBegin(GL_QUADS);
		glColor3f(0.0f, 0.0f, 0.0f);
		glVertex3f(165.0f, 2.0f,  2.0f);
		glVertex3f(165.0f, 2.0f, 24.0f);
		glVertex3f(165.0f, 4.0f, 24.0f);
		glVertex3f(165.0f, 4.0f,  2.0f);
	glEnd();


	    //PARTE ARRIBA
	glBegin(GL_QUADS);
		glColor3f(0.5f, 0.3f, 0.0f);
		glVertex3f(167.0f, 4.0f,  2.0f);
		glVertex3f(165.0f, 4.0f, 2.0f);
		glVertex3f(165.0f, 4.0f, 24.0f);
		glVertex3f(167.0f, 4.0f,  24.0f);
	glEnd();

	//PARTE ENFRENTE
	glBegin(GL_QUADS);
		glColor3f(0.5f, 0.3f, 0.0f);
		glVertex3f(167.0f, 4.0f,  24.0f);
		glVertex3f(165.0f, 4.0f, 24.0f);
		glVertex3f(165.0f, 2.0f, 24.0f);
		glVertex3f(167.0f, 2.0f,  24.0f);
	glEnd();

	//PARTE DERECHA
	glBegin(GL_QUADS);
		glColor3f(0.5f, 0.3f, 0.0f);
		glVertex3f(167.0f, 2.0f,  24.0f);
		glVertex3f(167.0f, 2.0f, 2.0f);
		glVertex3f(167.0f, 4.0f, 2.0f);
		glVertex3f(167.0f, 4.0f,  24.0f);
	glEnd();


    //PARTE DE ABAJO
    glBegin(GL_QUADS);
		glColor3f(0.5f, 0.3f, 0.0f);
		glVertex3f(165.0f, 2.0f,  24.0f);
		glVertex3f(165.0f, 2.0f, 2.0f);
		glVertex3f(167.0f, 2.0f, 2.0f);
		glVertex3f(167.0f, 2.0f,  24.0f);
	glEnd();
}

void dibujaCilindro(float radio, float alt)
{
	float a[3], b[3], c[3], d[3];
	float ang, delta, deltaColor;
	int lados;

	CVector *NormalPlano, vec1, vec2;
	CVector Nv1, Nv2, Nv3, Nv4;

	lados=10;

	NormalPlano=new CVector[lados];

	delta=360.0f/lados;
	deltaColor=1.0f/lados;

	//Primer ciclo: se calculan las normales por plano sin dibujar el cilindro
	for(int i=0; i < lados; i++)
	{
		ang=i*delta;
		
		a[0]=radio*(float)cos(ang*PI/180.0f);
		a[1]=0.0f;
		a[2]=radio*(float)sin(ang*PI/180.0f);

		b[0]=a[0];
		b[1]=alt;
		b[2]=a[2];

		ang=(i+1)*delta;
		
		c[0]=radio*(float)cos(ang*PI/180.0f);
		c[1]=alt;
		c[2]=radio*(float)sin(ang*PI/180.0f);

		d[0]=c[0];
		d[1]=0.0f;
		d[2]=c[2];

		//Se calculan dos vectores sobre el plano:
		vec1.x=a[0]-d[0];
		vec1.y=a[1]-d[1];
		vec1.z=a[2]-d[2];

		vec2.x=c[0]-d[0];
		vec2.y=c[1]-d[1];
		vec2.z=c[2]-d[2];

		//Se obtiene un vector perpendicular al plano mediante el producto cruz y se normaliza
		NormalPlano[i]=Normaliza(Cruz(vec1, vec2));
		
	}

	//Segundo ciclo: se calculan las normales por v�rtice y se dibuja el cilindro usando las normales calculadas.
	for(int i=0; i < lados; i++)
	{
		ang=i*delta;
		
		a[0]=radio*(float)cos(ang*PI/180.0f);
		a[1]=0.0f;
		a[2]=radio*(float)sin(ang*PI/180.0f);

		b[0]=a[0];
		b[1]=alt;
		b[2]=a[2];

		ang=(i+1)*delta;
		
		c[0]=radio*(float)cos(ang*PI/180.0f);
		c[1]=alt;
		c[2]=radio*(float)sin(ang*PI/180.0f);

		d[0]=c[0];
		d[1]=0.0f;
		d[2]=c[2];

		//C�lculo de normales por v�rtice: se interpolan las normales de los planos adyacentes
		if(i == 0)
		{
			Nv1=(NormalPlano[i]+NormalPlano[lados-1])/2.0f;
			Nv4=(NormalPlano[i]+NormalPlano[i+1])/2.0f;
			Nv2=Nv1;
			Nv3=Nv4;
		}
		else if(i == lados-1)
		{
			Nv1=(NormalPlano[i]+NormalPlano[i-1])/2.0f;
			Nv4=(NormalPlano[i]+NormalPlano[0])/2.0f;
			Nv2=Nv1;
			Nv3=Nv4;
		}
		else
		{
			Nv1=(NormalPlano[i]+NormalPlano[i-1])/2.0f;
			Nv4=(NormalPlano[i]+NormalPlano[i+1])/2.0f;
			Nv2=Nv1;
			Nv3=Nv4;
		}

		glColor3f(deltaColor*i, deltaColor*i, 0.0f);

		glBegin(GL_QUADS);
		//	glNormal3f(Nv1.x, Nv1.y, Nv1.z);
			glVertex3f(a[0], a[1], a[2]);
		//	glNormal3f(Nv2.x, Nv2.y, Nv2.z);
			glVertex3f(b[0], b[1], b[2]);
		//	glNormal3f(Nv3.x, Nv3.y, Nv3.z);
			glVertex3f(c[0], c[1], c[2]);
		//	glNormal3f(Nv4.x, Nv4.y, Nv4.z);
			glVertex3f(d[0], d[1], d[2]);
		glEnd();

		//Tapa superior
		glColor3f(0.7f,0.7f,0.7f);

		glBegin(GL_TRIANGLES);
	//		glNormal3f(0.0f, 1.0f, 0.0f);
			glVertex3f(c[0], c[1], c[2]);
			glVertex3f(b[0], b[1], b[2]);
			glVertex3f(0.0f, alt, 0.0f);
		glEnd();

		//Tapa inferior
		glColor3f(0.7f,0.7f,0.7f);

		glBegin(GL_TRIANGLES);
//			glNormal3f(0.0f, -1.0f, 0.0f);
			glVertex3f(a[0], a[1], a[2]);
			glVertex3f(d[0], d[1], d[2]);
			glVertex3f(0.0f, 0.0f, 0.0f);
		glEnd();

		glColor3f(1.0f,1.0f,1.0f);
	}

	delete[] NormalPlano;
}

void dibujaEdificio1(){
	//EDIFICIO 1 INICIA


	//PARED DELANTERA INICIO  CON VENTANAS Y CUADROS 
	

	//pared delantera inferior
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f(   0.0f, 0.0f,   0.0f);
		glVertex3f( 125.0f, 0.0f,   0.0f);
		glVertex3f( 125.0f, 3.0f,   0.0f);
		glVertex3f(   0.0f, 3.0f,   0.0f);
	glEnd();

	//pared delantera superior
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f(   0.0f,60.0f,   0.0f);
		glVertex3f( 125.0f,60.0f,   0.0f);
		glVertex3f( 125.0f,90.0f,   0.0f);
		glVertex3f(   0.0f,90.0f,   0.0f);
	glEnd();

	//pared delantera izquierda
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f(   0.0f, 3.0f,   0.0f);
		glVertex3f(   5.0f, 3.0f,   0.0f);
		glVertex3f(   5.0f,60.0f,   0.0f);
		glVertex3f(   0.0f,60.0f,   0.0f);
	glEnd();

	//pared delantera centro 1
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f( 29.0f, 3.0f,   0.0f);
		glVertex3f( 35.0f, 3.0f,   0.0f);
		glVertex3f( 35.0f,60.0f,   0.0f);
		glVertex3f( 29.0f,60.0f,   0.0f);
	glEnd();

	//pared delantera centro 2
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f( 59.5f, 3.0f,   0.0f);
		glVertex3f( 65.5f, 3.0f,   0.0f);
		glVertex3f( 65.5f,60.0f,   0.0f);
		glVertex3f( 59.5f,60.0f,   0.0f);
	glEnd();

	//pared delantera centro 3
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f( 89.5f, 3.0f,   0.0f);
		glVertex3f( 95.5f, 3.0f,   0.0f);
		glVertex3f( 95.5f,60.0f,   0.0f);
		glVertex3f( 89.5f,60.0f,   0.0f);
	glEnd();

	//pared delantera derecha
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f( 120.0f, 3.0f,   0.0f);
		glVertex3f( 125.0f, 3.0f,   0.0f);
		glVertex3f( 125.0f,60.0f,   0.0f);
		glVertex3f( 120.0f,60.0f,   0.0f);
	glEnd();


	//ventana-1-pared delantera inicio 

	//ventana 1
	glBegin(GL_QUADS);
		glColor3f(0.5f,0.5f,0.5f);
		glVertex3f( 5.0f, 3.0f,-1.5f);
		glVertex3f(29.0f, 3.0f,-1.5f);
		glVertex3f(29.0f,60.0f,-1.5f);
		glVertex3f( 5.0f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-1-izquierda
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f( 5.0f, 3.0f, 0.0f);
		glVertex3f( 5.0f, 3.0f,-1.5f);
		glVertex3f( 5.0f,60.0f,-1.5f);
		glVertex3f( 5.0f,60.0f, 0.0f);
	glEnd();

	//marco-ventana-1-derecha
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(29.0f, 3.0f,-1.5f);
		glVertex3f(29.0f, 3.0f, 0.0f);
		glVertex3f(29.0f,60.0f, 0.0f);
		glVertex3f(29.0f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-1-inferior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f( 5.0f, 3.0f, 0.0f);
		glVertex3f(29.0f, 3.0f, 0.0f);
		glVertex3f(29.0f, 3.0f,-1.5f);
		glVertex3f( 5.0f, 3.0f,-1.5f);
	glEnd();

	//marco-ventana-1-superior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(29.0f, 60.0f, 0.0f);
		glVertex3f( 5.0f, 60.0f, 0.0f);
		glVertex3f( 5.0f, 60.0f,-1.5f);
		glVertex3f(29.0f, 60.0f,-1.5f);
	glEnd();

	//ventana-1- pared delantera fin

	//ventana-2-pared delantera inicio 

	//ventana 2 
	glBegin(GL_QUADS);
		glColor3f(0.5f,0.5f,0.5f);
		glVertex3f(35.0f, 3.0f,-1.5f);
		glVertex3f(59.5f, 3.0f,-1.5f);
		glVertex3f(59.5f,60.0f,-1.5f);
		glVertex3f(35.0f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-2-izquierda
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(35.0f, 3.0f, 0.0f);
		glVertex3f(35.0f, 3.0f,-1.5f);
		glVertex3f(35.0f,60.0f,-1.5f);
		glVertex3f(35.0f,60.0f, 0.0f);
	glEnd();

	//marco-ventana-2-derecha
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(59.5f, 3.0f,-1.5f);
		glVertex3f(59.5f, 3.0f, 0.0f);
		glVertex3f(59.5f,60.0f, 0.0f);
		glVertex3f(59.5f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-2-inferior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(35.0f, 3.0f, 0.0f);
		glVertex3f(59.5f, 3.0f, 0.0f);
		glVertex3f(59.5f, 3.0f,-1.5f);
		glVertex3f(35.0f, 3.0f,-1.5f);
	glEnd();

	//marco-ventana-2-superior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(50.5f, 60.0f, 0.0f);
		glVertex3f(35.0f, 60.0f, 0.0f);
		glVertex3f(35.0f, 60.0f,-1.5f);
		glVertex3f(59.5f, 60.0f,-1.5f);
	glEnd();

	//ventana-2- pared delantera fin

	//ventana-3-pared delantera inicio 

	//ventana 3 
	glBegin(GL_QUADS);
		glColor3f(0.5f,0.5f,0.5f);
		glVertex3f(65.5f, 3.0f,-1.5f);
		glVertex3f(89.5f, 3.0f,-1.5f);
		glVertex3f(89.5f,60.0f,-1.5f);
		glVertex3f(65.5f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-3-izquierda
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(65.5f, 3.0f, 0.0f);
		glVertex3f(65.5f, 3.0f,-1.5f);
		glVertex3f(65.5f,60.0f,-1.5f);
		glVertex3f(65.5f,60.0f, 0.0f);
	glEnd();

	//marco-ventana-3-derecha
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(89.5f, 3.0f,-1.5f);
		glVertex3f(89.5f, 3.0f, 0.0f);
		glVertex3f(89.5f,60.0f, 0.0f);
		glVertex3f(89.5f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-3-inferior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(65.5f, 3.0f, 0.0f);
		glVertex3f(89.5f, 3.0f, 0.0f);
		glVertex3f(65.5f, 3.0f,-1.5f);
		glVertex3f(89.5f, 3.0f,-1.5f);
	glEnd();

	//marco-ventana-3-superior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(89.5f, 60.0f, 0.0f);
		glVertex3f(65.5f, 60.0f, 0.0f);
		glVertex3f(65.5f, 60.0f,-1.5f);
		glVertex3f(89.5f, 60.0f,-1.5f);
	glEnd();

	//ventana-3- pared delantera fin

	//ventana-4-pared delantera inicio 

	//ventana 4 
	glBegin(GL_QUADS);
		glColor3f(0.5f,0.5f,0.5f);
		glVertex3f( 95.5f, 3.0f,-1.5f);
		glVertex3f(120.0f, 3.0f,-1.5f);
		glVertex3f(120.0f,60.0f,-1.5f);
		glVertex3f( 95.5f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-4-izquierda
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(95.5f, 3.0f, 0.0f);
		glVertex3f(95.5f, 3.0f,-1.5f);
		glVertex3f(95.5f,60.0f,-1.5f);
		glVertex3f(95.5f,60.0f, 0.0f);
	glEnd();

	//marco-ventana-4-derecha
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(120.0f, 3.0f,-1.5f);
		glVertex3f(120.0f, 3.0f, 0.0f);
		glVertex3f(120.0f,60.0f, 0.0f);
		glVertex3f(120.0f,60.0f,-1.5f);
	glEnd();

	//marco-ventana-4-inferior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f( 95.5f, 3.0f, 0.0f);
		glVertex3f(120.0f, 3.0f, 0.0f);
		glVertex3f(120.0f, 3.0f,-1.5f);
		glVertex3f( 95.5f, 3.0f,-1.5f);
	glEnd();

	//marco-ventana-4-superior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.62f);
		glVertex3f(120.0f, 60.0f, 0.0f);
		glVertex3f( 95.5f, 60.0f, 0.0f);
		glVertex3f( 95.5f, 60.0f,-1.5f);
		glVertex3f(120.0f, 60.0f,-1.5f);
	glEnd();

	//ventana-4- pared delantera fin

	//cuadro superior 1
	glPushMatrix();
		glTranslatef(17.0f,70.0f,0.0f);
		glScalef(4.0f,3.0f, 0.4f);
		glRotatef(90.0f,1.0f, 0.0f, 0.0f);
		dibujaCaja();
	glPopMatrix();

	//cuadro superior 2
	glPushMatrix();
		glTranslatef(47.0f,70.0f,0.0f);
		glScalef(4.0f,3.0f, 0.4f);
		glRotatef(90.0f,1.0f, 0.0f, 0.0f);
		dibujaCaja();
	glPopMatrix();

	//cuadro superior 3
	glPushMatrix();
		glTranslatef(77.0f,70.0f,0.0f);
		glScalef(4.0f,3.0f, 0.4f);
		glRotatef(90.0f,1.0f, 0.0f, 0.0f);
		dibujaCaja();
	glPopMatrix();

	//cuadro superior 4
	glPushMatrix();
		glTranslatef(107.0f,70.0f,0.0f);
		glScalef(4.0f,3.0f, 0.4f);
		glRotatef(90.0f,1.0f, 0.0f, 0.0f);
		dibujaCaja();
	glPopMatrix();



	//PARED DELANTERA FIN  CON VENTANAS Y CUADROS

	//IMAGE
	glPushMatrix();
		glTranslatef(50.0f,50.0f,0.0f);
		dibujaIMAGE();
	glPopMatrix();

	//PARED DERECHA INICIO

	glPushMatrix();
		glTranslatef(125.0f,0.0f,0.0f);
		glRotatef(50.0f,0.0f,1.0f,0.0f);
			//pared derecha inferior
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.25f,0.25f);
				glVertex3f(   0.0f, 0.0f,   0.0f);
				glVertex3f( 125.0f, 0.0f,   0.0f);
				glVertex3f( 125.0f, 3.0f,   0.0f);
				glVertex3f(   0.0f, 3.0f,   0.0f);
			glEnd();

			//pared derecha superior
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.25f,0.25f);
				glVertex3f(   0.0f,60.0f,   0.0f);
				glVertex3f( 125.0f,60.0f,   0.0f);
				glVertex3f( 125.0f,80.0f,   0.0f);
				glVertex3f(   0.0f,80.0f,   0.0f);
			glEnd();

			//pared derecha izquierda
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.25f,0.25f);
				glVertex3f(   0.0f, 3.0f,   0.0f);
				glVertex3f(   5.0f, 3.0f,   0.0f);
				glVertex3f(   5.0f,60.0f,   0.0f);
				glVertex3f(   0.0f,60.0f,   0.0f);
			glEnd();

			//pared derecha centro 1
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.25f,0.25f);
				glVertex3f( 29.0f, 3.0f,   0.0f);
				glVertex3f( 35.0f, 3.0f,   0.0f);
				glVertex3f( 35.0f,60.0f,   0.0f);
				glVertex3f( 29.0f,60.0f,   0.0f);
			glEnd();

			//pared derecha centro 2
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.25f,0.25f);
				glVertex3f( 59.5f, 3.0f,   0.0f);
				glVertex3f( 65.5f, 3.0f,   0.0f);
				glVertex3f( 65.5f,60.0f,   0.0f);
				glVertex3f( 59.5f,60.0f,   0.0f);
			glEnd();

			//pared derecha centro 3
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.25f,0.25f);
				glVertex3f( 89.5f, 3.0f,   0.0f);
				glVertex3f( 95.5f, 3.0f,   0.0f);
				glVertex3f( 95.5f,60.0f,   0.0f);
				glVertex3f( 89.5f,60.0f,   0.0f);
			glEnd();

			//pared derecha derecha
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.25f,0.25f);
				glVertex3f( 120.0f, 3.0f,   0.0f);
				glVertex3f( 125.0f, 3.0f,   0.0f);
				glVertex3f( 125.0f,60.0f,   0.0f);
				glVertex3f( 120.0f,60.0f,   0.0f);
			glEnd();


			//ventana-1-pared derecha inicio 

			//ventana 1
			glBegin(GL_QUADS);
				glColor3f(0.5f,0.5f,0.5f);
				glVertex3f( 5.0f, 3.0f,-1.5f);
				glVertex3f(29.0f, 3.0f,-1.5f);
				glVertex3f(29.0f,60.0f,-1.5f);
				glVertex3f( 5.0f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-1-izquierda
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f( 5.0f, 3.0f, 0.0f);
				glVertex3f( 5.0f, 3.0f,-1.5f);
				glVertex3f( 5.0f,60.0f,-1.5f);
				glVertex3f( 5.0f,60.0f, 0.0f);
			glEnd();

			//marco-ventana-1-derecha
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(29.0f, 3.0f,-1.5f);
				glVertex3f(29.0f, 3.0f, 0.0f);
				glVertex3f(29.0f,60.0f, 0.0f);
				glVertex3f(29.0f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-1-inferior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f( 5.0f, 3.0f, 0.0f);
				glVertex3f(29.0f, 3.0f, 0.0f);
				glVertex3f(29.0f, 3.0f,-1.5f);
				glVertex3f( 5.0f, 3.0f,-1.5f);
			glEnd();

			//marco-ventana-1-superior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(29.0f, 60.0f, 0.0f);
				glVertex3f( 5.0f, 60.0f, 0.0f);
				glVertex3f( 5.0f, 60.0f,-1.5f);
				glVertex3f(29.0f, 60.0f,-1.5f);
			glEnd();

			//ventana-1- pared derecha fin

			//ventana-2-pared delantera inicio 

			//ventana 2 
			glBegin(GL_QUADS);
				glColor3f(0.5f,0.5f,0.5f);
				glVertex3f(35.0f, 3.0f,-1.5f);
				glVertex3f(59.5f, 3.0f,-1.5f);
				glVertex3f(59.5f,60.0f,-1.5f);
				glVertex3f(35.0f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-2-izquierda
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(35.0f, 3.0f, 0.0f);
				glVertex3f(35.0f, 3.0f,-1.5f);
				glVertex3f(35.0f,60.0f,-1.5f);
				glVertex3f(35.0f,60.0f, 0.0f);
			glEnd();

			//marco-ventana-2-derecha
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(59.5f, 3.0f,-1.5f);
				glVertex3f(59.5f, 3.0f, 0.0f);
				glVertex3f(59.5f,60.0f, 0.0f);
				glVertex3f(59.5f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-2-inferior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(35.0f, 3.0f, 0.0f);
				glVertex3f(59.5f, 3.0f, 0.0f);
				glVertex3f(59.5f, 3.0f,-1.5f);
				glVertex3f(35.0f, 3.0f,-1.5f);
			glEnd();

			//marco-ventana-2-superior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(50.5f, 60.0f, 0.0f);
				glVertex3f(35.0f, 60.0f, 0.0f);
				glVertex3f(35.0f, 60.0f,-1.5f);
				glVertex3f(59.5f, 60.0f,-1.5f);
			glEnd();

			//ventana-2- pared derecha fin

			//ventana-3-pared derecha inicio 

			//ventana 3 
			glBegin(GL_QUADS);
				glColor3f(0.5f,0.5f,0.5f);
				glVertex3f(65.5f, 3.0f,-1.5f);
				glVertex3f(89.5f, 3.0f,-1.5f);
				glVertex3f(89.5f,60.0f,-1.5f);
				glVertex3f(65.5f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-3-izquierda
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(65.5f, 3.0f, 0.0f);
				glVertex3f(65.5f, 3.0f,-1.5f);
				glVertex3f(65.5f,60.0f,-1.5f);
				glVertex3f(65.5f,60.0f, 0.0f);
			glEnd();

			//marco-ventana-3-derecha
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(89.5f, 3.0f,-1.5f);
				glVertex3f(89.5f, 3.0f, 0.0f);
				glVertex3f(89.5f,60.0f, 0.0f);
				glVertex3f(89.5f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-3-inferior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(65.5f, 3.0f, 0.0f);
				glVertex3f(89.5f, 3.0f, 0.0f);
				glVertex3f(65.5f, 3.0f,-1.5f);
				glVertex3f(89.5f, 3.0f,-1.5f);
			glEnd();

			//marco-ventana-3-superior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(89.5f, 60.0f, 0.0f);
				glVertex3f(65.5f, 60.0f, 0.0f);
				glVertex3f(65.5f, 60.0f,-1.5f);
				glVertex3f(89.5f, 60.0f,-1.5f);
			glEnd();

			//ventana-3- pared derecha fin

			//ventana-4-pared derecha inicio 

			//ventana 4 
			glBegin(GL_QUADS);
				glColor3f(0.5f,0.5f,0.5f);
				glVertex3f( 95.5f, 3.0f,-1.5f);
				glVertex3f(120.0f, 3.0f,-1.5f);
				glVertex3f(120.0f,60.0f,-1.5f);
				glVertex3f( 95.5f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-4-izquierda
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(95.5f, 3.0f, 0.0f);
				glVertex3f(95.5f, 3.0f,-1.5f);
				glVertex3f(95.5f,60.0f,-1.5f);
				glVertex3f(95.5f,60.0f, 0.0f);
			glEnd();

			//marco-ventana-4-derecha
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(120.0f, 3.0f,-1.5f);
				glVertex3f(120.0f, 3.0f, 0.0f);
				glVertex3f(120.0f,60.0f, 0.0f);
				glVertex3f(120.0f,60.0f,-1.5f);
			glEnd();

			//marco-ventana-4-inferior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f( 95.5f, 3.0f, 0.0f);
				glVertex3f(120.0f, 3.0f, 0.0f);
				glVertex3f(120.0f, 3.0f,-1.5f);
				glVertex3f( 95.5f, 3.0f,-1.5f);
			glEnd();

			//marco-ventana-4-superior
			glBegin(GL_QUADS);
				glColor3f(1.0f,1.0f,0.62f);
				glVertex3f(120.0f, 60.0f, 0.0f);
				glVertex3f( 95.5f, 60.0f, 0.0f);
				glVertex3f( 95.5f, 60.0f,-1.5f);
				glVertex3f(120.0f, 60.0f,-1.5f);
			glEnd();

			//ventana-4- pared derecha fin

			//cuadro superior 1
			glPushMatrix();
				glTranslatef(17.0f,70.0f,0.0f);
				glScalef(4.0f,3.0f, 0.4f);
				glRotatef(90.0f,1.0f, 0.0f, 0.0f);
				dibujaCaja();
			glPopMatrix();

			//cuadro superior 2
			glPushMatrix();
				glTranslatef(47.0f,70.0f,0.0f);
				glScalef(4.0f,3.0f, 0.4f);
				glRotatef(90.0f,1.0f, 0.0f, 0.0f);
				dibujaCaja();
			glPopMatrix();

			//cuadro superior 3
			glPushMatrix();
				glTranslatef(77.0f,70.0f,0.0f);
				glScalef(4.0f,3.0f, 0.4f);
				glRotatef(90.0f,1.0f, 0.0f, 0.0f);
				dibujaCaja();
			glPopMatrix();

			//cuadro superior 4
			glPushMatrix();
				glTranslatef(107.0f,70.0f,0.0f);
				glScalef(4.0f,3.0f, 0.4f);
				glRotatef(90.0f,1.0f, 0.0f, 0.0f);
				dibujaCaja();
			glPopMatrix();

		//poste-izquierdo INICIO
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.35f,0.35f);
				glVertex3f(29.5f, 0.0f,9.0f);
				glVertex3f(34.5f, 0.0f,9.0f);
				glVertex3f(34.5f,60.0f,9.0f);
				glVertex3f(29.5f,60.0f,9.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.47f,0.47f);
				glVertex3f(29.5f, 0.0f,0.0f);
				glVertex3f(29.5f, 0.0f,9.0f);
				glVertex3f(29.5f,60.0f,9.0f);
				glVertex3f(29.5f,60.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.47f,0.47f);
				glVertex3f(34.5f, 0.0f,9.0f);
				glVertex3f(34.5f, 0.0f,0.0f);
				glVertex3f(34.5f,60.0f,0.0f);
				glVertex3f(34.5f,60.0f,9.0f);
			glEnd();

		//Poste-izquierdo FIN

		//poste-derecho INICIO
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.35f,0.35f);
				glVertex3f(60.0f, 0.0f,9.0f);
				glVertex3f(65.0f, 0.0f,9.0f);
				glVertex3f(65.0f,60.0f,9.0f);
				glVertex3f(60.0f,60.0f,9.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.47f,0.47f);
				glVertex3f(60.0f, 0.0f,0.0f);
				glVertex3f(60.0f, 0.0f,9.0f);
				glVertex3f(60.0f,60.0f,9.0f);
				glVertex3f(60.0f,60.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.47f,0.47f);
				glVertex3f(65.0f, 0.0f,9.0f);
				glVertex3f(65.0f, 0.0f,0.0f);
				glVertex3f(65.0f,60.0f,0.0f);
				glVertex3f(65.0f,60.0f,9.0f);
			glEnd();

		//Poste-derecho FIN

		//carpa INICIO

			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.45f,0.9f,0.0f);
				glVertex3f(29.0f,58.0f,11.0f);
				glVertex3f(65.5f,58.0f,11.0f);
				glVertex3f(65.5f,70.0f,11.0f);
				glVertex3f(29.0f,70.0f,11.0f);
			glEnd();

			//plano superior
			glBegin(GL_QUADS);
				glColor3f(0.32f,0.64f,0.0f);
				glVertex3f(29.0f,70.0f,11.0f);
				glVertex3f(65.5f,70.0f,11.0f);
				glVertex3f(65.5f,70.0f,0.0f);
				glVertex3f(29.0f,70.0f,0.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.34f,0.68f,0.0f);
				glVertex3f(29.0f,58.0f,0.0f);
				glVertex3f(29.0f,58.0f,11.0f);
				glVertex3f(29.0f,70.0f,11.0f);
				glVertex3f(29.0f,70.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.34f,0.68f,0.0f);
				glVertex3f(65.5f,58.0f,11.0f);
				glVertex3f(65.5f,58.0f,0.0f);
				glVertex3f(65.5f,70.0f,0.0f);
				glVertex3f(65.5f,70.0f,11.0f);
			glEnd();

		//carpa FIN


	glPopMatrix();
	//PARED DERECHA FIN


	
	//pared izquierda 
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f(0.0f, 0.0f,-100.0f);
		glVertex3f(0.0f, 0.0f,   0.0f);
		glVertex3f(0.0f,80.0f,   0.0f);
		glVertex3f(0.0f,80.0f,-100.0f);
	glEnd();

	//TECHO INICIO

	glPushMatrix();
		glTranslatef(-2.0f,0.0f,-5.0f);
		glRotatef(-4.0f,0.0f,1.0f,0.0f);
		glScalef(1.06f,1.0f,1.0f);
	//techo-inferior 
	glBegin(GL_QUADS);
		glColor3f(0.43f,0.0f,0.0f);
		glVertex3f( 125.0f, 80.0f, 30.0f);
		glVertex3f( -15.0f, 80.0f, 30.0f);
		glVertex3f( -15.0f, 80.0f,-115.0f);
		glVertex3f( 210.0f, 80.0f,-115.0f);
	glEnd();

	//techo-superior 
	glBegin(GL_QUADS);
		glColor3f(0.43f,0.0f,0.0f);
		glVertex3f( -15.0f, 90.0f, 30.0f);
		glVertex3f( 125.0f, 90.0f, 30.0f);
		glVertex3f( 210.0f, 90.0f,-115.0f);
		glVertex3f( -15.0f, 90.0f,-115.0f);
	glEnd();

	//techo-delantero 
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.23f,0.23f);
		glVertex3f(-15.0f, 80.0f,30.0f);
		glVertex3f(125.0f, 80.0f,30.0f);
		glVertex3f(125.0f, 90.0f,30.0f);
		glVertex3f(-15.0f, 90.0f,30.0f);
	glEnd();

	//techo-derecha 
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f(125.0f, 80.0f,30.0f);
		glVertex3f(210.0f, 80.0f,-115.0f);
		glVertex3f(210.0f, 90.0f,-115.0f);
		glVertex3f(125.0f, 90.0f,30.0f);
	glEnd();

	//techo-izquierda 
	glBegin(GL_QUADS);
		glColor3f(0.0f,0.25f,0.25f);
		glVertex3f(-15.0f, 80.0f,-115.0f);
		glVertex3f(-15.0f, 80.0f,30.0f);
		glVertex3f(-15.0f, 90.0f,30.0f);
		glVertex3f(-15.0f, 90.0f,-115.0f);
	glEnd();

	glPopMatrix();
	//TECHO FIN

	glPushMatrix();
		glTranslatef(130.0f,0.0f,15.0f);
		dibujaCilindro(6.0f,90.0f);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-10.0f,0.0f,15.0f);
		dibujaCilindro(6.0f,90.0f);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-2.0f,0.0f,-108.0f);
		dibujaCilindro(6.0f,80.0f);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(214.0f,0.0f,-97.0f);
		dibujaCilindro(6.0f,80.0f);
	glPopMatrix();
    
	//EDIFICIO 1 FIN

}

void dibujaEdificio2(){
	
	//PARED DELANTERA INICIO	

		//pared-delantera-superior
		glBegin(GL_QUADS);
			glColor3f(0.35f,0.f,0.0f);
			glVertex3f(0.0f, 90.0f,0.0f);
			glVertex3f(125.0f,90.0f,0.0f);
			glVertex3f(125.0f,110.0f,0.0f);
			glVertex3f(0.0f,110.0f,0.0f);
		glEnd();

		//poste izquierdo INICIO

			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.85f,0.65f);
				glVertex3f(0.0f,  0.0f,2.0f);
				glVertex3f(8.0f,  0.0f,2.0f);
				glVertex3f(8.0f,110.0f,2.0f);
				glVertex3f(0.0f,110.0f,2.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(0.0f,  0.0f,0.0f);
				glVertex3f(0.0f,  0.0f,2.0f);
				glVertex3f(0.0f,110.0f,2.0f);
				glVertex3f(0.0f,110.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(8.0f,  0.0f,2.0f);
				glVertex3f(8.0f,  0.0f,0.0f);
				glVertex3f(8.0f,110.0f,0.0f);
				glVertex3f(8.0f,110.0f,2.0f);
			glEnd();

		//poste izquierdo FIN

		//poste derecho INICIO

			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.85f,0.65f);
				glVertex3f(117.0f,  0.0f,2.0f);
				glVertex3f(125.0f,  0.0f,2.0f);
				glVertex3f(125.0f,110.0f,2.0f);
				glVertex3f(117.0f,110.0f,2.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(117.0f,  0.0f,0.0f);
				glVertex3f(117.0f,  0.0f,2.0f);
				glVertex3f(117.0f,110.0f,2.0f);
				glVertex3f(117.0f,110.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(125.0f,  0.0f,2.0f);
				glVertex3f(125.0f,  0.0f,0.0f);
				glVertex3f(125.0f,110.0f,0.0f);
				glVertex3f(125.0f,110.0f,2.0f);
			glEnd();

		//poste derecho FIN

		//pared-delantera-superior-2
		glBegin(GL_QUADS);
			glColor3f(0.99f,0.9f,0.73f);
			glVertex3f(  8.0f, 80.0f,0.0f);
			glVertex3f(117.0f, 80.0f,0.0f);
			glVertex3f(117.0f, 90.0f,0.0f);
			glVertex3f(  8.0f, 90.0f,0.0f);
		glEnd();

		//pared-delantera-inferior-1-izquierdo INICIO
			
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.9f,0.67f,0.38f);
				glVertex3f(  8.0f,  0.0f,1.0f);
				glVertex3f( 47.0f,  0.0f,1.0f);
				glVertex3f( 47.0f, 10.0f,1.0f);
				glVertex3f(  8.0f, 10.0f,1.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.45f,0.0f,0.0f);
				glVertex3f( 47.0f,  0.0f,1.0f);
				glVertex3f( 47.0f,  0.0f,-6.0f);
				glVertex3f( 47.0f, 10.0f,-6.0f);
				glVertex3f( 47.0f, 10.0f,1.0f);
			glEnd();

			//plano superior
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f( 8.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f, 0.0f);
				glVertex3f( 8.0f, 10.0f, 0.0f);
			glEnd();

			//plano superior-derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f(47.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f,-6.0f);
				glVertex3f(46.0f, 10.0f,-6.0f);
				glVertex3f(46.0f, 10.0f, 1.0f);
			glEnd();

		//pared-delantera-inferior-1-izquierdo FIN

		//pared-delantera-inferior-1-derecho INICIO
			
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.9f,0.67f,0.38f);
				glVertex3f( 76.0f,  0.0f,1.0f);
				glVertex3f(125.0f,  0.0f,1.0f);
				glVertex3f(125.0f, 10.0f,1.0f);
				glVertex3f( 76.0f, 10.0f,1.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.45f,0.0f,0.0f);
				glVertex3f(76.0f,  0.0f,-6.0f);
				glVertex3f(76.0f,  0.0f, 1.0f);
				glVertex3f(76.0f, 10.0f, 1.0f);
				glVertex3f(76.0f, 10.0f,-6.0f);
			glEnd();

			//plano superior
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f( 76.0f, 10.0f, 1.0f);
				glVertex3f(125.0f, 10.0f, 1.0f);
				glVertex3f(125.0f, 10.0f, 0.0f);
				glVertex3f( 76.0f, 10.0f, 0.0f);
			glEnd();

			//plano superior-izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f(76.0f, 10.0f,-6.0f);
				glVertex3f(76.0f, 10.0f, 1.0f);
				glVertex3f(77.0f, 10.0f, 1.0f);
				glVertex3f(77.0f, 10.0f,-6.0f);
			glEnd();

		//pared-delantera-inferior-1-derecho FIN

		//pared delantera-central INICIO

				//superior
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(  8.0f, 76.0f,0.0f);
					glVertex3f(117.0f, 76.0f,0.0f);
					glVertex3f(117.0f, 80.0f,0.0f);
					glVertex3f(  8.0f, 80.0f,0.0f);
				glEnd();

			//PLANO IZQUIERDO INICIO

				//izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f( 8.0f,17.0f,0.0f);
					glVertex3f(10.0f,17.0f,0.0f);
					glVertex3f(10.0f,76.0f,0.0f);
					glVertex3f( 8.0f,76.0f,0.0f);
				glEnd();

				//derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(44.0f,17.0f,0.0f);
					glVertex3f(46.0f,17.0f,0.0f);
					glVertex3f(46.0f,76.0f,0.0f);
					glVertex3f(44.0f,76.0f,0.0f);
				glEnd();

				//central-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(16.0f,17.0f,0.0f);
					glVertex3f(18.0f,17.0f,0.0f);
					glVertex3f(18.0f,76.0f,0.0f);
					glVertex3f(16.0f,76.0f,0.0f);
				glEnd();

				//central-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(36.0f,17.0f,0.0f);
					glVertex3f(38.0f,17.0f,0.0f);
					glVertex3f(38.0f,76.0f,0.0f);
					glVertex3f(36.0f,76.0f,0.0f);
				glEnd();

				
				//central-central-izquierda INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(10.0f,17.0f,-1.0f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(10.0f,17.0f, 0.0f);
						glVertex3f(10.0f,17.0f,-1.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
						glVertex3f(10.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(10.0f,17.0f, 0.0f);
						glVertex3f(16.0f,17.0f, 0.0f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(10.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(16.0f,76.0f, 0.0f);
						glVertex3f(10.0f,76.0f, 0.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(16.0f,17.0f, 0.0f);
						glVertex3f(16.0f,76.0f, 0.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
					glEnd();

				//central-central-izquierda FIN

				//central-central-derecha INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(38.0f,17.0f,-1.0f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
					glEnd();
					
					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(38.0f,17.0f, 0.0f);
						glVertex3f(38.0f,17.0f,-1.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
						glVertex3f(38.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(38.0f,17.0f, 0.0f);
						glVertex3f(44.0f,17.0f, 0.0f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(38.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(44.0f,76.0f, 0.0f);
						glVertex3f(38.0f,76.0f, 0.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(44.0f,17.0f, 0.0f);
						glVertex3f(44.0f,76.0f, 0.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
					glEnd();

				//central-central-derecha FIN

				//pared delantera inferior-2-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(  8.0f, 10.0f,0.0f);
					glVertex3f( 46.0f, 10.0f,0.0f);
					glVertex3f( 46.0f, 17.0f,0.0f);
					glVertex3f(  8.0f, 17.0f,0.0f);
				glEnd();

				//PLANO CENTRAL   TEXTURA
				glBegin(GL_QUADS);
					glColor3f(0.7f,0.7f,0.7f);
					glVertex3f( 18.0f, 17.0f,0.0f);
					glVertex3f( 36.0f, 17.0f,0.0f);
					glVertex3f( 36.0f, 76.0f,0.0f);
					glVertex3f( 18.0f, 76.0f,0.0f);
				glEnd();

				//carpa INICIO

					//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 18.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 77.5f,0.0f);
						glVertex3f( 18.0f, 77.5f,0.0f);
					glEnd();

					//izquierdo
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 18.0f, 68.0f,0.0f);
						glVertex3f( 18.0f, 68.0f,3.0f);
						glVertex3f( 18.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 36.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 68.0f,0.0f);
						glVertex3f( 36.0f, 77.5f,0.0f);
					glEnd();


				//carpa FIN

			//PLANO IZQUIERDO FIN

			//PLANO DERECHO INICIO

				//izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(77.0f,17.0f,0.0f);
					glVertex3f(79.0f,17.0f,0.0f);
					glVertex3f(79.0f,76.0f,0.0f);
					glVertex3f(77.0f,76.0f,0.0f);
				glEnd();

				//derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(115.0f,17.0f,0.0f);
					glVertex3f(117.0f,17.0f,0.0f);
					glVertex3f(117.0f,76.0f,0.0f);
					glVertex3f(115.0f,76.0f,0.0f);
				glEnd();

				//central-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(85.0f,17.0f,0.0f);
					glVertex3f(87.0f,17.0f,0.0f);
					glVertex3f(87.0f,76.0f,0.0f);
					glVertex3f(85.0f,76.0f,0.0f);
				glEnd();

				//central-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(107.0f,17.0f,0.0f);
					glVertex3f(109.0f,17.0f,0.0f);
					glVertex3f(109.0f,76.0f,0.0f);
					glVertex3f(107.0f,76.0f,0.0f);
				glEnd();

				//central-central-izquierda INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(79.0f,17.0f,-1.0f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(79.0f,17.0f, 0.0f);
						glVertex3f(79.0f,17.0f,-1.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
						glVertex3f(79.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(79.0f,17.0f, 0.0f);
						glVertex3f(85.0f,17.0f, 0.0f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(79.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(85.0f,76.0f, 0.0f);
						glVertex3f(79.0f,76.0f, 0.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(85.0f,17.0f, 0.0f);
						glVertex3f(85.0f,76.0f, 0.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
					glEnd();

				//central-central-izquierda FIN

				//central-central-derecha INICIO
					
					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(109.0f,17.0f,-1.0f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(109.0f,17.0f, 0.0f);
						glVertex3f(109.0f,17.0f,-1.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
						glVertex3f(109.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(109.0f,17.0f, 0.0f);
						glVertex3f(115.0f,17.0f, 0.0f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(109.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(115.0f,76.0f, 0.0f);
						glVertex3f(109.0f,76.0f, 0.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(115.0f,17.0f, 0.0f);
						glVertex3f(115.0f,76.0f, 0.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
					glEnd();

				//central-central-derecha FIN

				//pared delantera inferior-2-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f( 77.0f, 10.0f,0.0f);
					glVertex3f(117.0f, 10.0f,0.0f);
					glVertex3f(117.0f, 17.0f,0.0f);
					glVertex3f( 77.0f, 17.0f,0.0f);
				glEnd();

				//PLANO CENTRAL TEXTURA
				glBegin(GL_QUADS);
					glColor3f(0.7f,0.7f,0.7f);
					glVertex3f( 87.0f, 17.0f,0.0f);
					glVertex3f(107.0f, 17.0f,0.0f);
					glVertex3f(107.0f, 76.0f,0.0f);
					glVertex3f( 87.0f, 76.0f,0.0f);
				glEnd();

				//carpa INICIO
					//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 87.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 77.5f,0.0f);
						glVertex3f( 87.0f, 77.5f,0.0f);
					glEnd();

					//izquierdo
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f(87.0f, 68.0f,0.0f);
						glVertex3f(87.0f, 68.0f,3.0f);
						glVertex3f(87.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f(107.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 68.0f,0.0f);
						glVertex3f(107.0f, 77.5f,0.0f);
					glEnd();


				//carpa FIN

			//PLANO DERECHO FIN
		//pared delantera-central FIN

		//PARED INTERIOR INICIO

		    //pared interior derecha
			glBegin(GL_QUADS);
				glColor3f(0.47f,0.0f,0.0f);
				glVertex3f( 46.0f, 10.0f, 0.0f);
				glVertex3f( 46.0f, 10.0f,-6.0f);
				glVertex3f( 46.0f, 80.0f,-6.0f);
				glVertex3f( 46.0f, 80.0f, 0.0f);
			glEnd();

			//pared interior izquierda
			glBegin(GL_QUADS);
				glColor3f(0.47f,0.0f,0.0f);
				glVertex3f(77.0f, 10.0f,-6.0f);
				glVertex3f(77.0f, 10.0f, 0.0f);
				glVertex3f(77.0f, 80.0f, 0.0f);
				glVertex3f(77.0f, 80.0f,-6.0f);
			glEnd();

			//pared interior central
			glBegin(GL_QUADS);
				glColor3f(0.6f,0.6f,0.0f);
				glVertex3f(46.0f, 0.0f,-6.0f);
				glVertex3f(77.0f, 0.0f,-6.0f);
				glVertex3f(77.0f,80.0f,-6.0f);
				glVertex3f(46.0f,80.0f,-6.0f);
			glEnd();

			//carpa INICIO

				//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 46.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 46.0f, 68.0f,0.0f);
						glVertex3f( 46.0f, 68.0f,3.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
						glVertex3f( 46.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 77.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 68.0f,0.0f);
						glVertex3f( 77.0f, 77.5f,0.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
						glVertex3f( 77.0f, 77.5f,0.0f);
						glVertex3f( 46.0f, 77.5f,0.0f);
					glEnd();


			//carpa FIN

		//PARED INTERIOR FIN


	//PARED DELANTERA FINAL

	//PARED DERECHA INICIO
	glPushMatrix();
		glTranslatef(120.0f,0.0f,1.0f);
		glRotatef(90.0f,0.0f,1.0f,0.0f);

		//pared izquierda
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(  0.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
			glVertex3f(  0.0f,110.0f,5.0f);
		glEnd();

		//pared derecha
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(125.0f,  0.0f,5.0f);
			glVertex3f(125.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
		glEnd();


		//pared interior-izquierda
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
		glEnd();

		//pared interior-derecha
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,0.0f);
		glEnd();

		//pared central
			
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
		glEnd();


		//pared interior-central FIN
	glPopMatrix();

	//PARED DERECHA FIN

	//PARED IZQUIERDA INICIO 
	
    glPushMatrix();
		
		glTranslatef(-58.0f,0.0f,-109.0f);
		glRotatef(-60.0f,0.0f,1.0f,0.0f);
		//pared central-superior
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.0f);
			glVertex3f( 10.0f, 76.0f,0.0f);
			glVertex3f(115.0f, 76.0f,0.0f);
			glVertex3f(115.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
		glEnd();

		//pared izquierda
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(  0.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
			glVertex3f(  0.0f,110.0f,5.0f);
		glEnd();

		//pared derecha
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(125.0f,  0.0f,5.0f);
			glVertex3f(125.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
		glEnd();

		//pared inferior
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f, 16.0f,0.0f);
			glVertex3f( 10.0f, 16.0f,0.0f);
		glEnd();

		//pared interior-izquierda
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
		glEnd();

		//pared interior-derecha
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,0.0f);
		glEnd();

		//pared central
			
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.5f);
			glVertex3f( 10.0f, 16.0f,0.0f);
			glVertex3f(115.0f, 16.0f,0.0f);
			glVertex3f(115.0f, 76.0f,0.0f);
			glVertex3f( 10.0f, 76.0f,0.0f);
		glEnd();

		//carpa INICIO

			//frontal
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.6f,0.f);
				glVertex3f( 10.0f, 66.0f,10.0f);
				glVertex3f(115.0f, 66.0f,10.0f);
				glVertex3f(115.0f, 76.0f,5.0f);
				glVertex3f( 10.0f, 76.0f,5.0f);
			glEnd();

			//superior
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.2f,0.f);
				glVertex3f( 10.0f, 76.0f,5.0f);
				glVertex3f(115.0f, 76.0f,5.0f);
				glVertex3f(115.0f, 76.0f,0.0f);
				glVertex3f( 10.0f, 76.0f,0.0f);
			glEnd();

			//izquierda
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.2f,0.f);
				glVertex3f( 10.0f, 66.0f, 0.0f);
				glVertex3f( 10.0f, 66.0f,10.0f);
				glVertex3f( 10.0f, 76.0f, 5.0f);
				glVertex3f( 10.0f, 76.0f, 0.0f);
			glEnd();

			//derecha
			glBegin(GL_QUADS);
				glColor3f(0.0f,0.2f,0.f);
				glVertex3f(115.0f, 66.0f,10.0f);
				glVertex3f(115.0f, 66.0f, 0.0f);
				glVertex3f(115.0f, 76.0f, 0.0f);
				glVertex3f(115.0f, 76.0f, 5.0f);
			glEnd();

		//carpa FIN

		//pared interior-central FIN
	glPopMatrix();

	//PARED IZQUIERDA FIN

	//TECHO
	glBegin(GL_QUADS);
		glColor3f(0.4f,0.0f,0.f);
		glVertex3f(  0.0f,110.0f,   3.0f);
		glVertex3f(125.0f,110.0f,   3.0f);
		glVertex3f(125.0f,110.0f,-125.0f);
		glVertex3f(-67.0f,110.0f,-115.0f);
	glEnd();

	//TECHO2
	glBegin(GL_QUADS);
		glColor3f(0.4f,0.0f,0.f);
		glVertex3f(125.0f,110.0f,   3.0f);
		glVertex3f(  0.0f,110.0f,   3.0f);
		glVertex3f(-67.0f,110.0f,-115.0f);
		glVertex3f(125.0f,110.0f,-125.0f);
	glEnd();

}

void dibujaEdificio4(){


	//PARED DELANTERA INICIO	

		//pared-delantera-superior
		glBegin(GL_QUADS);
			glColor3f(0.35f,0.f,0.0f);
			glVertex3f(0.0f, 90.0f,0.0f);
			glVertex3f(125.0f,90.0f,0.0f);
			glVertex3f(125.0f,110.0f,0.0f);
			glVertex3f(0.0f,110.0f,0.0f);
		glEnd();

		//poste izquierdo INICIO

			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.85f,0.65f);
				glVertex3f(0.0f,  0.0f,2.0f);
				glVertex3f(8.0f,  0.0f,2.0f);
				glVertex3f(8.0f,110.0f,2.0f);
				glVertex3f(0.0f,110.0f,2.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(0.0f,  0.0f,0.0f);
				glVertex3f(0.0f,  0.0f,2.0f);
				glVertex3f(0.0f,110.0f,2.0f);
				glVertex3f(0.0f,110.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(8.0f,  0.0f,2.0f);
				glVertex3f(8.0f,  0.0f,0.0f);
				glVertex3f(8.0f,110.0f,0.0f);
				glVertex3f(8.0f,110.0f,2.0f);
			glEnd();

		//poste izquierdo FIN

		//poste derecho INICIO

			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.85f,0.65f);
				glVertex3f(117.0f,  0.0f,2.0f);
				glVertex3f(125.0f,  0.0f,2.0f);
				glVertex3f(125.0f,110.0f,2.0f);
				glVertex3f(117.0f,110.0f,2.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(117.0f,  0.0f,0.0f);
				glVertex3f(117.0f,  0.0f,2.0f);
				glVertex3f(117.0f,110.0f,2.0f);
				glVertex3f(117.0f,110.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(125.0f,  0.0f,2.0f);
				glVertex3f(125.0f,  0.0f,0.0f);
				glVertex3f(125.0f,110.0f,0.0f);
				glVertex3f(125.0f,110.0f,2.0f);
			glEnd();

		//poste derecho FIN

		//pared-delantera-superior-2
		glBegin(GL_QUADS);
			glColor3f(0.99f,0.9f,0.73f);
			glVertex3f(  8.0f, 80.0f,0.0f);
			glVertex3f(117.0f, 80.0f,0.0f);
			glVertex3f(117.0f, 90.0f,0.0f);
			glVertex3f(  8.0f, 90.0f,0.0f);
		glEnd();

		//pared-delantera-inferior-1-izquierdo INICIO
			
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.9f,0.67f,0.38f);
				glVertex3f(  8.0f,  0.0f,1.0f);
				glVertex3f( 47.0f,  0.0f,1.0f);
				glVertex3f( 47.0f, 10.0f,1.0f);
				glVertex3f(  8.0f, 10.0f,1.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.39f,0.0f,0.0f);
				glVertex3f( 47.0f,  0.0f,1.0f);
				glVertex3f( 47.0f,  0.0f,-6.0f);
				glVertex3f( 47.0f, 10.0f,-6.0f);
				glVertex3f( 47.0f, 10.0f,1.0f);
			glEnd();

			//plano superior
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f( 8.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f, 0.0f);
				glVertex3f( 8.0f, 10.0f, 0.0f);
			glEnd();

			//plano superior-derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f(47.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f,-6.0f);
				glVertex3f(46.0f, 10.0f,-6.0f);
				glVertex3f(46.0f, 10.0f, 1.0f);
			glEnd();

		//pared-delantera-inferior-1-izquierdo FIN

		//pared-delantera-inferior-1-derecho INICIO
			
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.9f,0.67f,0.38f);
				glVertex3f( 76.0f,  0.0f,1.0f);
				glVertex3f(125.0f,  0.0f,1.0f);
				glVertex3f(125.0f, 10.0f,1.0f);
				glVertex3f( 76.0f, 10.0f,1.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.39f,0.0f,0.0f);
				glVertex3f(76.0f,  0.0f,-6.0f);
				glVertex3f(76.0f,  0.0f, 1.0f);
				glVertex3f(76.0f, 10.0f, 1.0f);
				glVertex3f(76.0f, 10.0f,-6.0f);
			glEnd();

			//plano superior
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f( 76.0f, 10.0f, 1.0f);
				glVertex3f(125.0f, 10.0f, 1.0f);
				glVertex3f(125.0f, 10.0f, 0.0f);
				glVertex3f( 76.0f, 10.0f, 0.0f);
			glEnd();

			//plano superior-izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f(76.0f, 10.0f,-6.0f);
				glVertex3f(76.0f, 10.0f, 1.0f);
				glVertex3f(77.0f, 10.0f, 1.0f);
				glVertex3f(77.0f, 10.0f,-6.0f);
			glEnd();

		//pared-delantera-inferior-1-derecho FIN

		//pared delantera-central INICIO

				//superior
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(  8.0f, 76.0f,0.0f);
					glVertex3f(117.0f, 76.0f,0.0f);
					glVertex3f(117.0f, 80.0f,0.0f);
					glVertex3f(  8.0f, 80.0f,0.0f);
				glEnd();

			//PLANO IZQUIERDO INICIO

				//izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f( 8.0f,17.0f,0.0f);
					glVertex3f(10.0f,17.0f,0.0f);
					glVertex3f(10.0f,76.0f,0.0f);
					glVertex3f( 8.0f,76.0f,0.0f);
				glEnd();

				//derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(44.0f,17.0f,0.0f);
					glVertex3f(46.0f,17.0f,0.0f);
					glVertex3f(46.0f,76.0f,0.0f);
					glVertex3f(44.0f,76.0f,0.0f);
				glEnd();

				//central-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(16.0f,17.0f,0.0f);
					glVertex3f(18.0f,17.0f,0.0f);
					glVertex3f(18.0f,76.0f,0.0f);
					glVertex3f(16.0f,76.0f,0.0f);
				glEnd();

				//central-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(36.0f,17.0f,0.0f);
					glVertex3f(38.0f,17.0f,0.0f);
					glVertex3f(38.0f,76.0f,0.0f);
					glVertex3f(36.0f,76.0f,0.0f);
				glEnd();

				
				//central-central-izquierda INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(10.0f,17.0f,-1.0f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(10.0f,17.0f, 0.0f);
						glVertex3f(10.0f,17.0f,-1.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
						glVertex3f(10.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(10.0f,17.0f, 0.0f);
						glVertex3f(16.0f,17.0f, 0.0f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(10.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(16.0f,76.0f, 0.0f);
						glVertex3f(10.0f,76.0f, 0.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(16.0f,17.0f, 0.0f);
						glVertex3f(16.0f,76.0f, 0.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
					glEnd();

				//central-central-izquierda FIN

				//central-central-derecha INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(38.0f,17.0f,-1.0f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
					glEnd();
					
					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(38.0f,17.0f, 0.0f);
						glVertex3f(38.0f,17.0f,-1.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
						glVertex3f(38.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(38.0f,17.0f, 0.0f);
						glVertex3f(44.0f,17.0f, 0.0f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(38.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(44.0f,76.0f, 0.0f);
						glVertex3f(38.0f,76.0f, 0.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(44.0f,17.0f, 0.0f);
						glVertex3f(44.0f,76.0f, 0.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
					glEnd();

				//central-central-derecha FIN

				//pared delantera inferior-2-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(  8.0f, 10.0f,0.0f);
					glVertex3f( 46.0f, 10.0f,0.0f);
					glVertex3f( 46.0f, 17.0f,0.0f);
					glVertex3f(  8.0f, 17.0f,0.0f);
				glEnd();

				//PLANO CENTRAL 
				glBegin(GL_QUADS);
					glColor3f(0.7f,0.7f,0.7f);
					glVertex3f( 18.0f, 17.0f,0.0f);
					glVertex3f( 36.0f, 17.0f,0.0f);
					glVertex3f( 36.0f, 76.0f,0.0f);
					glVertex3f( 18.0f, 76.0f,0.0f);
				glEnd();

				//carpa INICIO

					//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 18.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 77.5f,0.0f);
						glVertex3f( 18.0f, 77.5f,0.0f);
					glEnd();

					//izquierdo
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 18.0f, 68.0f,0.0f);
						glVertex3f( 18.0f, 68.0f,3.0f);
						glVertex3f( 18.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 36.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 68.0f,0.0f);
						glVertex3f( 36.0f, 77.5f,0.0f);
					glEnd();


				//carpa FIN


			//PLANO IZQUIERDO FIN

			//PLANO DERECHO INICIO

				//izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(77.0f,17.0f,0.0f);
					glVertex3f(79.0f,17.0f,0.0f);
					glVertex3f(79.0f,76.0f,0.0f);
					glVertex3f(77.0f,76.0f,0.0f);
				glEnd();

				//derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(115.0f,17.0f,0.0f);
					glVertex3f(117.0f,17.0f,0.0f);
					glVertex3f(117.0f,76.0f,0.0f);
					glVertex3f(115.0f,76.0f,0.0f);
				glEnd();

				//central-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(85.0f,17.0f,0.0f);
					glVertex3f(87.0f,17.0f,0.0f);
					glVertex3f(87.0f,76.0f,0.0f);
					glVertex3f(85.0f,76.0f,0.0f);
				glEnd();

				//central-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(107.0f,17.0f,0.0f);
					glVertex3f(109.0f,17.0f,0.0f);
					glVertex3f(109.0f,76.0f,0.0f);
					glVertex3f(107.0f,76.0f,0.0f);
				glEnd();

				//central-central-izquierda INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(79.0f,17.0f,-1.0f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(79.0f,17.0f, 0.0f);
						glVertex3f(79.0f,17.0f,-1.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
						glVertex3f(79.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(79.0f,17.0f, 0.0f);
						glVertex3f(85.0f,17.0f, 0.0f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(79.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(85.0f,76.0f, 0.0f);
						glVertex3f(79.0f,76.0f, 0.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(85.0f,17.0f, 0.0f);
						glVertex3f(85.0f,76.0f, 0.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
					glEnd();

				//central-central-izquierda FIN

				//central-central-derecha INICIO
					
					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(109.0f,17.0f,-1.0f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(109.0f,17.0f, 0.0f);
						glVertex3f(109.0f,17.0f,-1.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
						glVertex3f(109.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(109.0f,17.0f, 0.0f);
						glVertex3f(115.0f,17.0f, 0.0f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(109.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(115.0f,76.0f, 0.0f);
						glVertex3f(109.0f,76.0f, 0.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(115.0f,17.0f, 0.0f);
						glVertex3f(115.0f,76.0f, 0.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
					glEnd();

				//central-central-derecha FIN

				//pared delantera inferior-2-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f( 77.0f, 10.0f,0.0f);
					glVertex3f(117.0f, 10.0f,0.0f);
					glVertex3f(117.0f, 17.0f,0.0f);
					glVertex3f( 77.0f, 17.0f,0.0f);
				glEnd();

				//PLANO CENTRAL 
				glBegin(GL_QUADS);
					glColor3f(0.7f,0.7f,0.7f);
					glVertex3f( 87.0f, 17.0f,0.0f);
					glVertex3f(107.0f, 17.0f,0.0f);
					glVertex3f(107.0f, 76.0f,0.0f);
					glVertex3f( 87.0f, 76.0f,0.0f);
				glEnd();

				//carpa INICIO
					//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 87.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 77.5f,0.0f);
						glVertex3f( 87.0f, 77.5f,0.0f);
					glEnd();

					//izquierdo
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f(87.0f, 68.0f,0.0f);
						glVertex3f(87.0f, 68.0f,3.0f);
						glVertex3f(87.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f(107.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 68.0f,0.0f);
						glVertex3f(107.0f, 77.5f,0.0f);
					glEnd();


				//carpa FIN		
	
			//PLANO DERECHO FIN
		//pared delantera-central FIN

		//PARED INTERIOR INICIO

		    //pared interior derecha
			glBegin(GL_QUADS);
				glColor3f(0.47f,0.0f,0.0f);
				glVertex3f( 46.0f, 10.0f, 0.0f);
				glVertex3f( 46.0f, 10.0f,-6.0f);
				glVertex3f( 46.0f, 80.0f,-6.0f);
				glVertex3f( 46.0f, 80.0f, 0.0f);
			glEnd();

			//pared interior izquierda
			glBegin(GL_QUADS);
				glColor3f(0.47f,0.0f,0.0f);
				glVertex3f(77.0f, 10.0f,-6.0f);
				glVertex3f(77.0f, 10.0f, 0.0f);
				glVertex3f(77.0f, 80.0f, 0.0f);
				glVertex3f(77.0f, 80.0f,-6.0f);
			glEnd();

			//pared interior central
			glBegin(GL_QUADS);
				glColor3f(0.6f,0.6f,0.0f);
				glVertex3f(46.0f, 0.0f,-6.0f);
				glVertex3f(77.0f, 0.0f,-6.0f);
				glVertex3f(77.0f,80.0f,-6.0f);
				glVertex3f(46.0f,80.0f,-6.0f);
			glEnd();

			//carpa INICIO

				//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 46.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 46.0f, 68.0f,0.0f);
						glVertex3f( 46.0f, 68.0f,3.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
						glVertex3f( 46.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 77.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 68.0f,0.0f);
						glVertex3f( 77.0f, 77.5f,0.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
						glVertex3f( 77.0f, 77.5f,0.0f);
						glVertex3f( 46.0f, 77.5f,0.0f);
					glEnd();


			//carpa FIN

		//PARED INTERIOR FIN


	//PARED DELANTERA FINAL

	//PARED DERECHA INICIO
	glPushMatrix();
		glTranslatef(120.0f,0.0f,1.0f);
		glRotatef(90.0f,0.0f,1.0f,0.0f);

		//pared izquierda
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(  0.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
			glVertex3f(  0.0f,110.0f,5.0f);
		glEnd();

		//pared derecha
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(125.0f,  0.0f,5.0f);
			glVertex3f(125.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
		glEnd();


		//pared interior-izquierda
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
		glEnd();

		//pared interior-derecha
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,0.0f);
		glEnd();

		//pared central
			
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
		glEnd();


		//pared interior-central FIN
	glPopMatrix();

	//PARED DERECHA FIN

	//PARED IZQUIERDA INICIO 
	
    glPushMatrix();
		
		glTranslatef(5.0f,0.0f,-121.0f);
		glRotatef(-90.0f,0.0f,1.0f,0.0f);

		//pared central
			
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
		glEnd();

		//pared izquierda
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(  0.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
			glVertex3f(  0.0f,110.0f,5.0f);
		glEnd();

		//pared derecha
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(125.0f,  0.0f,5.0f);
			glVertex3f(125.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
		glEnd();


		//pared interior-izquierda
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
		glEnd();

		//pared interior-derecha
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,0.0f);
		glEnd();

		//pared interior-central FIN
	glPopMatrix();

	//PARED IZQUIERDA FIN

	//TECHO
	glBegin(GL_QUADS);
		glColor3f(0.4f,0.0f,0.f);
		glVertex3f(  0.0f,110.0f,   3.0f);
		glVertex3f(125.0f,110.0f,   3.0f);
		glVertex3f(125.0f,110.0f,-125.0f);
		glVertex3f(  0.0f,110.0f,-125.0f);
	glEnd();

	//TECHO2
	glBegin(GL_QUADS);
		glColor3f(0.4f,0.0f,0.f);
		glVertex3f(125.0f,110.0f,   3.0f);
		glVertex3f(  0.0f,110.0f,   3.0f);
		glVertex3f(  0.0f,110.0f,-125.0f);
		glVertex3f(125.0f,110.0f,-125.0f);
	glEnd();


}


void dibujaEdificio3(){

	//PARED DELANTERA INICIO	

		//pared-delantera-superior
		glBegin(GL_QUADS);
			glColor3f(0.35f,0.f,0.0f);
			glVertex3f(0.0f, 90.0f,0.0f);
			glVertex3f(125.0f,90.0f,0.0f);
			glVertex3f(125.0f,110.0f,0.0f);
			glVertex3f(0.0f,110.0f,0.0f);
		glEnd();

		//poste izquierdo INICIO

			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.85f,0.65f);
				glVertex3f(0.0f,  0.0f,2.0f);
				glVertex3f(8.0f,  0.0f,2.0f);
				glVertex3f(8.0f,110.0f,2.0f);
				glVertex3f(0.0f,110.0f,2.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(0.0f,  0.0f,0.0f);
				glVertex3f(0.0f,  0.0f,2.0f);
				glVertex3f(0.0f,110.0f,2.0f);
				glVertex3f(0.0f,110.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(8.0f,  0.0f,2.0f);
				glVertex3f(8.0f,  0.0f,0.0f);
				glVertex3f(8.0f,110.0f,0.0f);
				glVertex3f(8.0f,110.0f,2.0f);
			glEnd();

		//poste izquierdo FIN

		//poste derecho INICIO

			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.85f,0.65f);
				glVertex3f(117.0f,  0.0f,2.0f);
				glVertex3f(125.0f,  0.0f,2.0f);
				glVertex3f(125.0f,110.0f,2.0f);
				glVertex3f(117.0f,110.0f,2.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(117.0f,  0.0f,0.0f);
				glVertex3f(117.0f,  0.0f,2.0f);
				glVertex3f(117.0f,110.0f,2.0f);
				glVertex3f(117.0f,110.0f,0.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.77f,0.48f);
				glVertex3f(125.0f,  0.0f,2.0f);
				glVertex3f(125.0f,  0.0f,0.0f);
				glVertex3f(125.0f,110.0f,0.0f);
				glVertex3f(125.0f,110.0f,2.0f);
			glEnd();

		//poste derecho FIN

		//pared-delantera-superior-2
		glBegin(GL_QUADS);
			glColor3f(0.99f,0.9f,0.73f);
			glVertex3f(  8.0f, 80.0f,0.0f);
			glVertex3f(117.0f, 80.0f,0.0f);
			glVertex3f(117.0f, 90.0f,0.0f);
			glVertex3f(  8.0f, 90.0f,0.0f);
		glEnd();

		//pared-delantera-inferior-1-izquierdo INICIO
			
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.9f,0.67f,0.38f);
				glVertex3f(  8.0f,  0.0f,1.0f);
				glVertex3f( 47.0f,  0.0f,1.0f);
				glVertex3f( 47.0f, 10.0f,1.0f);
				glVertex3f(  8.0f, 10.0f,1.0f);
			glEnd();

			//plano derecho
			glBegin(GL_QUADS);
				glColor3f(0.45f,0.0f,0.0f);
				glVertex3f( 47.0f,  0.0f,1.0f);
				glVertex3f( 47.0f,  0.0f,-6.0f);
				glVertex3f( 47.0f, 10.0f,-6.0f);
				glVertex3f( 47.0f, 10.0f,1.0f);
			glEnd();

			//plano superior
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f( 8.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f, 0.0f);
				glVertex3f( 8.0f, 10.0f, 0.0f);
			glEnd();

			//plano superior-derecho
			glBegin(GL_QUADS);
				glColor3f(0.99f,0.9f,0.73f);
				glVertex3f(47.0f, 10.0f, 1.0f);
				glVertex3f(47.0f, 10.0f,-6.0f);
				glVertex3f(46.0f, 10.0f,-6.0f);
				glVertex3f(46.0f, 10.0f, 1.0f);
			glEnd();

		//pared-delantera-inferior-1-izquierdo FIN

		//pared-delantera-inferior-1-derecho INICIO
			
			//plano delantero
			glBegin(GL_QUADS);
				glColor3f(0.9f,0.67f,0.38f);
				glVertex3f( 76.0f,  0.0f,1.0f);
				glVertex3f(125.0f,  0.0f,1.0f);
				glVertex3f(125.0f, 10.0f,1.0f);
				glVertex3f( 76.0f, 10.0f,1.0f);
			glEnd();

			//plano izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.45f,0.0f,0.0f);
				glVertex3f(76.0f,  0.0f,-6.0f);
				glVertex3f(76.0f,  0.0f, 1.0f);
				glVertex3f(76.0f, 10.0f, 1.0f);
				glVertex3f(76.0f, 10.0f,-6.0f);
			glEnd();

			//plano superior
			glBegin(GL_QUADS);
				glColor3f(0.45f,0.0f,0.0f);
				glVertex3f( 76.0f, 10.0f, 1.0f);
				glVertex3f(125.0f, 10.0f, 1.0f);
				glVertex3f(125.0f, 10.0f, 0.0f);
				glVertex3f( 76.0f, 10.0f, 0.0f);
			glEnd();

			//plano superior-izquierdo
			glBegin(GL_QUADS);
				glColor3f(0.45f,0.0f,0.0f);
				glVertex3f(76.0f, 10.0f,-6.0f);
				glVertex3f(76.0f, 10.0f, 1.0f);
				glVertex3f(77.0f, 10.0f, 1.0f);
				glVertex3f(77.0f, 10.0f,-6.0f);
			glEnd();

		//pared-delantera-inferior-1-derecho FIN

		//pared delantera-central INICIO

				//superior
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(  8.0f, 76.0f,0.0f);
					glVertex3f(117.0f, 76.0f,0.0f);
					glVertex3f(117.0f, 80.0f,0.0f);
					glVertex3f(  8.0f, 80.0f,0.0f);
				glEnd();

			//PLANO IZQUIERDO INICIO

				//izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f( 8.0f,17.0f,0.0f);
					glVertex3f(10.0f,17.0f,0.0f);
					glVertex3f(10.0f,76.0f,0.0f);
					glVertex3f( 8.0f,76.0f,0.0f);
				glEnd();

				//derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(44.0f,17.0f,0.0f);
					glVertex3f(46.0f,17.0f,0.0f);
					glVertex3f(46.0f,76.0f,0.0f);
					glVertex3f(44.0f,76.0f,0.0f);
				glEnd();

				//central-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(16.0f,17.0f,0.0f);
					glVertex3f(18.0f,17.0f,0.0f);
					glVertex3f(18.0f,76.0f,0.0f);
					glVertex3f(16.0f,76.0f,0.0f);
				glEnd();

				//central-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(36.0f,17.0f,0.0f);
					glVertex3f(38.0f,17.0f,0.0f);
					glVertex3f(38.0f,76.0f,0.0f);
					glVertex3f(36.0f,76.0f,0.0f);
				glEnd();

				
				//central-central-izquierda INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(10.0f,17.0f,-1.0f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(10.0f,17.0f, 0.0f);
						glVertex3f(10.0f,17.0f,-1.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
						glVertex3f(10.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(10.0f,17.0f, 0.0f);
						glVertex3f(16.0f,17.0f, 0.0f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(10.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(16.0f,76.0f, 0.0f);
						glVertex3f(10.0f,76.0f, 0.0f);
						glVertex3f(10.0f,76.0f,-1.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(1.0f,1.0f,1.0f);
						glVertex3f(16.0f,17.0f,-1.0f);
						glVertex3f(16.0f,17.0f, 0.0f);
						glVertex3f(16.0f,76.0f, 0.0f);
						glVertex3f(16.0f,76.0f,-1.0f);
					glEnd();

				//central-central-izquierda FIN

				//central-central-derecha INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(38.0f,17.0f,-1.0f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
					glEnd();
					
					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(38.0f,17.0f, 0.0f);
						glVertex3f(38.0f,17.0f,-1.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
						glVertex3f(38.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(38.0f,17.0f, 0.0f);
						glVertex3f(44.0f,17.0f, 0.0f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(38.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(44.0f,76.0f, 0.0f);
						glVertex3f(38.0f,76.0f, 0.0f);
						glVertex3f(38.0f,76.0f,-1.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(44.0f,17.0f,-1.0f);
						glVertex3f(44.0f,17.0f, 0.0f);
						glVertex3f(44.0f,76.0f, 0.0f);
						glVertex3f(44.0f,76.0f,-1.0f);
					glEnd();

				//central-central-derecha FIN

				//pared delantera inferior-2-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(  8.0f, 10.0f,0.0f);
					glVertex3f( 46.0f, 10.0f,0.0f);
					glVertex3f( 46.0f, 17.0f,0.0f);
					glVertex3f(  8.0f, 17.0f,0.0f);
				glEnd();

				//PLANO CENTRAL 
				glBegin(GL_QUADS);
					glColor3f(0.7f,0.7f,0.7f);
					glVertex3f( 18.0f, 17.0f,0.0f);
					glVertex3f( 36.0f, 17.0f,0.0f);
					glVertex3f( 36.0f, 76.0f,0.0f);
					glVertex3f( 18.0f, 76.0f,0.0f);
				glEnd();

				//carpa INICIO

					//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 18.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 77.5f,0.0f);
						glVertex3f( 18.0f, 77.5f,0.0f);
					glEnd();

					//izquierdo
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 18.0f, 68.0f,0.0f);
						glVertex3f( 18.0f, 68.0f,3.0f);
						glVertex3f( 18.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 36.0f, 68.0f,3.0f);
						glVertex3f( 36.0f, 68.0f,0.0f);
						glVertex3f( 36.0f, 77.5f,0.0f);
					glEnd();


				//carpa FIN

				//maceta INICIO

					//frontal
					glBegin(GL_QUADS);
						glColor3f(1.0f,1.0f,1.0f);
						glVertex3f( 18.0f, 17.0f,4.0f);
						glVertex3f( 36.0f, 17.0f,4.0f);
						glVertex3f( 36.0f, 23.0f,4.0f);
						glVertex3f( 18.0f, 23.0f,4.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.3f,0.3f,0.3f);
						glVertex3f( 36.0f, 17.0f,4.0f);
						glVertex3f( 18.0f, 17.0f,4.0f);
						glVertex3f( 18.0f, 17.0f,0.0f);
						glVertex3f( 36.0f, 17.0f,0.0f);
					glEnd();

					//derecha
					glBegin(GL_QUADS);
						glColor3f(0.8f,0.8f,0.8f);
						glVertex3f(36.0f, 17.0f,4.0f);
						glVertex3f(36.0f, 17.0f,0.0f);
						glVertex3f(36.0f, 23.0f,0.0f);
						glVertex3f(36.0f, 23.0f,4.0f);
					glEnd();

					//izquierda
					glBegin(GL_QUADS);
						glColor3f(0.8f,0.8f,0.8f);
						glVertex3f(18.0f, 17.0f,0.0f);
						glVertex3f(18.0f, 17.0f,4.0f);
						glVertex3f(18.0f, 23.0f,4.0f);
						glVertex3f(18.0f, 23.0f,0.0f);
					glEnd();

				//maceta FIN

			//PLANO IZQUIERDO FIN

			//PLANO DERECHO INICIO

				//izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(77.0f,17.0f,0.0f);
					glVertex3f(79.0f,17.0f,0.0f);
					glVertex3f(79.0f,76.0f,0.0f);
					glVertex3f(77.0f,76.0f,0.0f);
				glEnd();

				//derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(115.0f,17.0f,0.0f);
					glVertex3f(117.0f,17.0f,0.0f);
					glVertex3f(117.0f,76.0f,0.0f);
					glVertex3f(115.0f,76.0f,0.0f);
				glEnd();

				//central-izquierda
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(85.0f,17.0f,0.0f);
					glVertex3f(87.0f,17.0f,0.0f);
					glVertex3f(87.0f,76.0f,0.0f);
					glVertex3f(85.0f,76.0f,0.0f);
				glEnd();

				//central-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f(107.0f,17.0f,0.0f);
					glVertex3f(109.0f,17.0f,0.0f);
					glVertex3f(109.0f,76.0f,0.0f);
					glVertex3f(107.0f,76.0f,0.0f);
				glEnd();

				//central-central-izquierda INICIO

					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(79.0f,17.0f,-1.0f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(79.0f,17.0f, 0.0f);
						glVertex3f(79.0f,17.0f,-1.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
						glVertex3f(79.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(79.0f,17.0f, 0.0f);
						glVertex3f(85.0f,17.0f, 0.0f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(79.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(85.0f,76.0f, 0.0f);
						glVertex3f(79.0f,76.0f, 0.0f);
						glVertex3f(79.0f,76.0f,-1.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(85.0f,17.0f,-1.0f);
						glVertex3f(85.0f,17.0f, 0.0f);
						glVertex3f(85.0f,76.0f, 0.0f);
						glVertex3f(85.0f,76.0f,-1.0f);
					glEnd();

				//central-central-izquierda FIN

				//central-central-derecha INICIO
					
					//plano frontal
					glBegin(GL_QUADS);
						glColor3f(0.95f,0.77f,0.68f);
						glVertex3f(109.0f,17.0f,-1.0f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(109.0f,17.0f, 0.0f);
						glVertex3f(109.0f,17.0f,-1.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
						glVertex3f(109.0f,76.0f, 0.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(109.0f,17.0f, 0.0f);
						glVertex3f(115.0f,17.0f, 0.0f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(109.0f,17.0f,-1.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(115.0f,76.0f, 0.0f);
						glVertex3f(109.0f,76.0f, 0.0f);
						glVertex3f(109.0f,76.0f,-1.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.96f,0.82f,0.76f);
						glVertex3f(115.0f,17.0f,-1.0f);
						glVertex3f(115.0f,17.0f, 0.0f);
						glVertex3f(115.0f,76.0f, 0.0f);
						glVertex3f(115.0f,76.0f,-1.0f);
					glEnd();

				//central-central-derecha FIN

				//pared delantera inferior-2-derecha
				glBegin(GL_QUADS);
					glColor3f(0.92f,0.66f,0.53f);
					glVertex3f( 77.0f, 10.0f,0.0f);
					glVertex3f(117.0f, 10.0f,0.0f);
					glVertex3f(117.0f, 17.0f,0.0f);
					glVertex3f( 77.0f, 17.0f,0.0f);
				glEnd();

				//PLANO CENTRAL 
				glBegin(GL_QUADS);
					glColor3f(0.7f,0.7f,0.7f);
					glVertex3f( 87.0f, 17.0f,0.0f);
					glVertex3f(107.0f, 17.0f,0.0f);
					glVertex3f(107.0f, 76.0f,0.0f);
					glVertex3f( 87.0f, 76.0f,0.0f);
				glEnd();

				//carpa INICIO
					//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 87.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 77.5f,0.0f);
						glVertex3f( 87.0f, 77.5f,0.0f);
					glEnd();

					//izquierdo
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f(87.0f, 68.0f,0.0f);
						glVertex3f(87.0f, 68.0f,3.0f);
						glVertex3f(87.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_TRIANGLES);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f(107.0f, 68.0f,3.0f);
						glVertex3f(107.0f, 68.0f,0.0f);
						glVertex3f(107.0f, 77.5f,0.0f);
					glEnd();


				//carpa FIN

				//maceta INICIO

					
					//frontal
					glBegin(GL_QUADS);
						glColor3f(1.0f,1.0f,1.0f);
						glVertex3f( 87.0f, 17.0f,4.0f);
						glVertex3f(107.0f, 17.0f,4.0f);
						glVertex3f(107.0f, 23.0f,4.0f);
						glVertex3f( 87.0f, 23.0f,4.0f);
					glEnd();

					//inferior
					glBegin(GL_QUADS);
						glColor3f(0.3f,0.3f,0.3f);
						glVertex3f(107.0f, 17.0f,4.0f);
						glVertex3f( 87.0f, 17.0f,4.0f);
						glVertex3f( 87.0f, 17.0f,0.0f);
						glVertex3f(107.0f, 17.0f,0.0f);
					glEnd();

					//derecha
					glBegin(GL_QUADS);
						glColor3f(0.8f,0.8f,0.8f);
						glVertex3f(107.0f, 17.0f,4.0f);
						glVertex3f(107.0f, 17.0f,0.0f);
						glVertex3f(107.0f, 23.0f,0.0f);
						glVertex3f(107.0f, 23.0f,4.0f);
					glEnd();

					//izquierda
					glBegin(GL_QUADS);
						glColor3f(0.8f,0.8f,0.8f);
						glVertex3f(87.0f, 17.0f,0.0f);
						glVertex3f(87.0f, 17.0f,4.0f);
						glVertex3f(87.0f, 23.0f,4.0f);
						glVertex3f(87.0f, 23.0f,0.0f);
					glEnd();

				//maceta FIN		
	
			//PLANO DERECHO FIN
		//pared delantera-central FIN

		//PARED INTERIOR INICIO

		    //pared interior derecha
			glBegin(GL_QUADS);
				glColor3f(0.47f,0.0f,0.0f);
				glVertex3f( 46.0f, 10.0f, 0.0f);
				glVertex3f( 46.0f, 10.0f,-6.0f);
				glVertex3f( 46.0f, 80.0f,-6.0f);
				glVertex3f( 46.0f, 80.0f, 0.0f);
			glEnd();

			//pared interior izquierda
			glBegin(GL_QUADS);
				glColor3f(0.47f,0.0f,0.0f);
				glVertex3f(77.0f, 10.0f,-6.0f);
				glVertex3f(77.0f, 10.0f, 0.0f);
				glVertex3f(77.0f, 80.0f, 0.0f);
				glVertex3f(77.0f, 80.0f,-6.0f);
			glEnd();

			//pared interior central
			glBegin(GL_QUADS);
				glColor3f(0.6f,0.6f,0.0f);
				glVertex3f(46.0f, 0.0f,-6.0f);
				glVertex3f(77.0f, 0.0f,-6.0f);
				glVertex3f(77.0f,80.0f,-6.0f);
				glVertex3f(46.0f,80.0f,-6.0f);
			glEnd();

			//carpa INICIO

				//frontal
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.7f,0.0f);
						glVertex3f( 46.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
					glEnd();

					//izquierdo
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 46.0f, 68.0f,0.0f);
						glVertex3f( 46.0f, 68.0f,3.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
						glVertex3f( 46.0f, 77.5f,0.0f);
					glEnd();

					//derecho
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 77.0f, 68.0f,3.0f);
						glVertex3f( 77.0f, 68.0f,0.0f);
						glVertex3f( 77.0f, 77.5f,0.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
					glEnd();

					//superior
					glBegin(GL_QUADS);
						glColor3f(0.0f,0.3f,0.0f);
						glVertex3f( 46.0f, 77.5f,3.0f);
						glVertex3f( 77.0f, 77.5f,3.0f);
						glVertex3f( 77.0f, 77.5f,0.0f);
						glVertex3f( 46.0f, 77.5f,0.0f);
					glEnd();


			//carpa FIN

		//PARED INTERIOR FIN


	//PARED DELANTERA FINAL

	//PARED DERECHA INICIO
	glPushMatrix();
		glTranslatef(120.0f,0.0f,1.0f);
		glRotatef(90.0f,0.0f,1.0f,0.0f);

		//pared izquierda
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(  0.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
			glVertex3f(  0.0f,110.0f,5.0f);
		glEnd();

		//pared derecha
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(125.0f,  0.0f,5.0f);
			glVertex3f(125.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
		glEnd();


		//pared interior-izquierda
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
		glEnd();

		//pared interior-derecha
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,0.0f);
		glEnd();

		//pared central
			
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
		glEnd();


		//pared interior-central FIN
	glPopMatrix();

	//PARED DERECHA FIN

	//PARED IZQUIERDA INICIO 
	
    glPushMatrix();
		
		glTranslatef(5.0f,0.0f,-121.0f);
		glRotatef(-90.0f,0.0f,1.0f,0.0f);

		//pared central
			
		glBegin(GL_QUADS);
			glColor3f(0.5f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
		glEnd();

		//pared izquierda
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(  0.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
			glVertex3f(  0.0f,110.0f,5.0f);
		glEnd();

		//pared derecha
		glBegin(GL_QUADS);
			glColor3f(0.39f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(125.0f,  0.0f,5.0f);
			glVertex3f(125.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
		glEnd();


		//pared interior-izquierda
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f( 10.0f,  0.0f,5.0f);
			glVertex3f( 10.0f,  0.0f,0.0f);
			glVertex3f( 10.0f,110.0f,0.0f);
			glVertex3f( 10.0f,110.0f,5.0f);
		glEnd();

		//pared interior-derecha
		glBegin(GL_QUADS);
			glColor3f(0.2f,0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,0.0f);
			glVertex3f(115.0f,  0.0f,5.0f);
			glVertex3f(115.0f,110.0f,5.0f);
			glVertex3f(115.0f,110.0f,0.0f);
		glEnd();

		//pared interior-central FIN
	glPopMatrix();

	//PARED IZQUIERDA FIN

	//TECHO
	glBegin(GL_QUADS);
		glColor3f(0.4f,0.0f,0.f);
		glVertex3f(  0.0f,110.0f,   3.0f);
		glVertex3f(125.0f,110.0f,   3.0f);
		glVertex3f(125.0f,110.0f,-125.0f);
		glVertex3f(  0.0f,110.0f,-125.0f);
	glEnd();

	//TECHO2
	glBegin(GL_QUADS);
		glColor3f(0.4f,0.0f,0.f);
		glVertex3f(125.0f,110.0f,   3.0f);
		glVertex3f(  0.0f,110.0f,   3.0f);
		glVertex3f(  0.0f,110.0f,-125.0f);
		glVertex3f(125.0f,110.0f,-125.0f);
	glEnd();


}

void dibujaCentroEdificios(){

	//pared frontal
	glBegin(GL_QUADS);
		glColor3f(0.5f,0.0f,0.0f);
		glVertex3f(0.0f,76.0f,0.0f);
		glVertex3f(80.0f,76.0f,0.0f);
		glVertex3f(80.0f,90.0f,0.0f);
		glVertex3f(0.0f,90.0f,0.0f);
	glEnd();

	//pared frontal inferior
	glBegin(GL_QUADS);
		glColor3f(1.0f,1.0f,0.75f);
		glVertex3f(0.0f,71.0f,0.0f);
		glVertex3f(80.0f,71.0f,0.0f);
		glVertex3f(80.0f,76.0f,0.0f);
		glVertex3f(0.0f,76.0f,0.0f);
	glEnd();

	//inferior
	glBegin(GL_QUADS);
		glColor3f(0.2f,0.2f,0.2f);
		glVertex3f(80.0f,71.0f,   0.0f);
		glVertex3f( 0.0f,71.0f,   0.0f);
		glVertex3f( 0.0f,71.0f,-125.0f);
		glVertex3f(80.0f,71.0f,-125.0f);
	glEnd();

	//superior
	glBegin(GL_QUADS);
		glColor3f(0.3f,0.3f,0.3f);
		glVertex3f( 0.0f,90.0f,   0.0f);
		glVertex3f(80.0f,90.0f,   0.0f);
		glVertex3f(80.0f,90.0f,-125.0f);
		glVertex3f( 0.0f,90.0f,-125.0f);
	glEnd();
}

void dibujaEscenario(int render)
{
	if(render == 1)//s�lido
		glPolygonMode(GL_FRONT,GL_FILL);
	else if(render == 2)//alambrado
		glPolygonMode(GL_FRONT,GL_LINE);

	dibujaEdificio1();

	glPushMatrix();
		glTranslatef(380.0f,0.0f,0.0f);
		dibujaEdificio2();
	glPopMatrix();

	glPushMatrix();
		glTranslatef(600.0f,0.0f,0.0f);
		dibujaEdificio3();
	glPopMatrix();

	glPushMatrix();
		glTranslatef(820.0f,0.0f,0.0f);
		dibujaEdificio4();
	glPopMatrix();

	glPushMatrix();
		glScalef(1.2f,1.0f,1.0f);
		glTranslatef(420.0f,0.0f,0.0f);
		dibujaCentroEdificios();
	glPopMatrix();

	glPushMatrix();
		glScalef(1.2f,1.0f,1.0f);
		glTranslatef(605.0f,0.0f,0.0f);
		dibujaCentroEdificios();
	glPopMatrix();

	//Se regresa al modo de dibujo s�lido en caso de haber usado modo alambrado
	if(render == 2)
		glPolygonMode(GL_FRONT,GL_FILL);

	//Siempre al final se vuelve al color blanco (default de OpenGL) para que otros gr�ficos no se vean afectados
	glColor3f(1.0f, 1.0f, 1.0f);
}




int RenderizaEscena(GLvoid)								// Aqui se dibuja todo lo que aparecera en la ventana
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	//gluLookAt(80.0f, 120.0f, 170.0f, 0.0f, 0.0f, 0.0f, 0, 1, 0);
	gluLookAt(PosCam.x, PosCam.y, PosCam.z, ObjCam.x, ObjCam.y, ObjCam.z, 0, 1, 0);
	
	DibujaEjes();
	dibujaEscenario(renderModo);
					
	return TRUE;
}

GLvoid DestruyeVentanaOGL(GLvoid)						// Elimina la ventana apropiadamente
{
	if (hRC)											// Si existe un contexto de renderizado...
	{
		if (!wglMakeCurrent(NULL,NULL))					// Si no se pueden liberar los contextos DC y RC...
		{
			MessageBox(NULL,"Falla al liberar DC y RC.","Error de finalizaci�n",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Si no se puede eliminar el RC?
		{
			MessageBox(NULL,"Falla al liberar el contexto de renderizado.","Error de finalizaci�n",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Se pone RC en NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Si no se puede eliminar el DC
	{
		MessageBox(NULL,"Falla al liberar el contexto de renderizado.","Error de finalizaci�n",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Se pone DC en NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Si no se puede destruir la ventana
	{
		MessageBox(NULL,"No se pudo liberar hWnd.","Error de finalizaci�n",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Se pone hWnd en NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Si no se puede eliminar el registro de la clase
	{
		MessageBox(NULL,"No se pudo eliminar el registro de la clase.","Error de finalizaci�n",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Se pone hInstance en NULL
	}
}

//	Este c�digo crea la ventana de OpenGL.  Par�metros:					
//	title			- Titulo en la parte superior de la ventana			
//	width			- Ancho de la ventana								
//	height			- Alto de la ventana								
//	bits			- N�mero de bits a usar para el color (8/16/24/32)	
  
BOOL CreaVentanaOGL(char* title, int width, int height, int bits)
{
	GLuint	PixelFormat;				// Guarda el resultado despues de determinar el formato a usar
	WNDCLASS	wc;						// Estructura de la clase ventana
	DWORD		dwExStyle;				// Estilo extendido de ventana
	DWORD		dwStyle;				// Estilo de ventana
	RECT		WindowRect;				// Guarda los valores Superior Izquierdo / Inferior Derecho del rect�ngulo
	WindowRect.left=(long)0;			// Inicia el valor Izquierdo a 0
	WindowRect.right=(long)width;		// Inicia el valor Derecho al ancho especificado
	WindowRect.top=(long)0;				// Inicia el valor Superior a 0
	WindowRect.bottom=(long)height;		// Inicia el valor Inferior al alto especificado

	hInstance			= GetModuleHandle(NULL);				// Guarda una instancia de la ventana
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redibuja el contenido de la ventana al redimensionarla
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// Maneja los mensajes para WndProc
	wc.cbClsExtra		= 0;									// Ningun dato extra para la clase
	wc.cbWndExtra		= 0;									// Ningun dato extra para la ventana
	wc.hInstance		= hInstance;							// Inicia la instancia
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Carga el �cono por defecto
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Carga el puntero de flecha
	wc.hbrBackground	= NULL;									// No se requiere ningun fondo
	wc.lpszMenuName		= NULL;									// No hay men� en la ventana
	wc.lpszClassName	= "OpenGL";								// Fija el nombre de la clase.

	if (!RegisterClass(&wc))									// Intenta registrar la clase de ventana
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											
	}
		
	dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;					// Estilo extendido de ventana
	dwStyle=WS_OVERLAPPEDWINDOW;									// Estilo de ventana

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Ajusta la ventana al tama�o especificado

	// Crea la ventana
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Estilo extendido para la ventana
								"OpenGL",							// Nombre de la clase
								title,								// T�tulo de la ventana
								dwStyle |							// Definici�n del estilo de la ventana
								WS_CLIPSIBLINGS |					// Estilo requerido de la ventana
								WS_CLIPCHILDREN,					// Estilo requerido de la ventana
								0, 0,								// Posici�n de la ventana
								WindowRect.right-WindowRect.left,	// Calcula el ancho de la ventana
								WindowRect.bottom-WindowRect.top,	// Calcula el alto de la ventana
								NULL,								// No hay ventana superior
								NULL,								// No hay men�
								hInstance,							// Instancia
								NULL)))								// No se pasa nada a WM_CREATE
	{
		DestruyeVentanaOGL();										// Resetea el despliegue
		MessageBox(NULL,"Error al crear la ventana.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Si no se creo el contexto de dispositivo...
	{
		DestruyeVentanaOGL();						// Resetea el despliegue
		MessageBox(NULL,"No se puede crear un contexto de dispositivo GL.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Si Windows no encontr� un formato de pixel compatible
	{
		DestruyeVentanaOGL();						// Resetea el despliegue
		MessageBox(NULL,"No se puede encontrar un formato de pixel compatible.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Si no se pudo habilitar el formato de pixel
	{
		DestruyeVentanaOGL();						// Resetea el despliegue
		MessageBox(NULL,"No se puede usar el formato de pixel.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								
	}

	if (!(hRC=wglCreateContext(hDC)))				// Si no se creo el contexto de renderizado
	{
		DestruyeVentanaOGL();						// Resetea el despliegue
		MessageBox(NULL,"No se puede crear un contexto de renderizado GL.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								
	}

	if(!wglMakeCurrent(hDC,hRC))					// Si no se puede activar el contexto de renderizado
	{
		DestruyeVentanaOGL();						// Resetea el despliegue
		MessageBox(NULL,"No se puede usar el contexto de renderizado GL.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								
	}

	ShowWindow(hWnd,SW_SHOW);				// Muestra la ventana
	SetForegroundWindow(hWnd);				// Le da la prioridad mas alta
	SetFocus(hWnd);							// Pasa el foco del teclado a la ventana
	ReDimensionaEscenaGL(width, height);	// Inicia la perspectiva para la ventana OGL

	if (!IniGL())							// Si no se inicializa la ventana creada
	{
		DestruyeVentanaOGL();				// Resetea el despliegue
		MessageBox(NULL,"Falla en la inicializaci�n.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								
	}

	return TRUE;							// Todo correcto
}

LRESULT CALLBACK WndProc(	HWND	hWnd,	// Manejador para esta ventana
							UINT	uMsg,	// Mensaje para esta ventana
							WPARAM	wParam,	// Informaci�n adicional del mensaje
							LPARAM	lParam)	// Informaci�n adicional del mensaje
{
	switch (uMsg)							// Revisa los mensajes de la ventana
	{
		case WM_ACTIVATE:					// Revisa el mensaje de activaci�n de ventana
		{
			if (!HIWORD(wParam))			// Revisa el estado de minimizaci�n
			{
				active=TRUE;				// El programa est� activo
			}
			else
			{
				active=FALSE;				// El programa no est� activo
			}

			return 0;						// Regresa al ciclo de mensajes
		}

		case WM_SYSCOMMAND:					// Intercepta comandos del sistema
		{
			switch (wParam)					// Revisa llamadas del sistema
			{
				case SC_SCREENSAVE:			// �Screensaver tratando de iniciar?
				case SC_MONITORPOWER:		// �Monitor tratando de entrar a modo de ahorro de energ�a?
				return 0;					// Evita que suceda
			}
			break;							// Sale del caso
		}

		case WM_CLOSE:						// Si se recibe un mensaje de cerrar...
		{
			PostQuitMessage(0);				// Se manda el mensaje de salida
			return 0;						// y se regresa al ciclo
		}

		case WM_KEYDOWN:					// Si se est� presionando una tecla...
		{
			keys[wParam] = TRUE;			// Si es as�, se marca como TRUE
			return 0;						// y se regresa al ciclo
		}

		case WM_KEYUP:						// �Se ha soltado una tecla?
		{
			keys[wParam] = FALSE;			// Si es as�, se marca como FALSE
			return 0;						// y se regresa al ciclo
		}

		case WM_SIZE:						// Si se redimensiona la ventana...
		{
			ReDimensionaEscenaGL(LOWORD(lParam),HIWORD(lParam));  	// LoWord=Width, HiWord=Height
			return 0;						// y se regresa al ciclo
		}
	}

	// Pasa todos los mensajes no considerados a DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

// Este es el punto de entrada al programa; la funci�n principal 
int WINAPI WinMain(	HINSTANCE	hInstance,			// Instancia
					HINSTANCE	hPrevInstance,		// Instancia previa
					LPSTR		lpCmdLine,			// Parametros de la linea de comandos
					int			nCmdShow)			// Muestra el estado de la ventana
{
	MSG		msg;									// Estructura de mensajes de la ventana
	BOOL	done=FALSE;								// Variable booleana para salir del ciclo

	// Crea la ventana OpenGL
	if (!CreaVentanaOGL("Laboratorio de Computaci�n Gr�fica",640,480,16))
	{
		return 0;									// Salir del programa si la ventana no fue creada
	}

	while(!done)									// Mientras done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Revisa si hay mensajes en espera
		{
			if (msg.message==WM_QUIT)				// Si se ha recibido el mensje de salir...
			{
				done=TRUE;							// Entonces done=TRUE
			}
			else									// Si no, Procesa los mensajes de la ventana
			{
				TranslateMessage(&msg);				// Traduce el mensaje
				DispatchMessage(&msg);				// Envia el mensaje
			}
		}
		else										// Si no hay mensajes...
		{
			// Dibuja la escena. 
			if (active)								// Si est� activo el programa...
			{
				if (keys[VK_ESCAPE])				// Si se ha presionado ESC
				{
					done=TRUE;						// ESC indica el termino del programa
				}
				else								// De lo contrario, actualiza la pantalla
				{
					RenderizaEscena();				// Dibuja la escena
					SwapBuffers(hDC);				// Intercambia los Buffers (Double Buffering)
				}

				if(!ManejaTeclado()) return 0;
			}
			
		}
	}

	// Finalizaci�n del programa
	DestruyeVentanaOGL();							// Destruye la ventana
	return (msg.wParam);							// Sale del programa
}

int ManejaTeclado()
{
	
	
	if(keys[VK_UP])
	{		
		PosCam.y+=0.5f;
		ObjCam.y+=0.5f;
	}
	if(keys[VK_DOWN])
	{
		PosCam.y-=0.5f;
		ObjCam.y-=0.5f;
	}
	if(keys[VK_LEFT])
	{
		PosCam.x-=0.5f;
		ObjCam.x-=0.5f;
	}
	if(keys[VK_RIGHT])
	{
		PosCam.x+=0.5f;
		ObjCam.x+=0.5f;
	}


	if(keys[VK_PRIOR])
	{
		
	}
	if(keys[VK_NEXT])
	{
		
	}

	if(keys[VK_HOME])
	{
		
	}

	if(keys[VK_END])
	{
		
	}

	if(keys['A'])
	{
		renderModo=1;
	}
	if(keys['S'])
	{
		renderModo=2;
	}

	return TRUE;
}